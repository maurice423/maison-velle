import { useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowRight,
  ArrowUpRight,
  BadgePercent,
  Brain,
  Check,
  ChevronRight,
  CreditCard,
  Lock,
  Mail,
  MapPin,
  Minus,
  Moon,
  Phone,
  Plus,
  RotateCcw,
  Search,
  Send,
  ShieldCheck,
  ShoppingBag,
  Sparkles,
  Star,
  Sun,
  Trash2,
  Truck,
  User,
  X,
  Apple as AppleIcon,
} from 'lucide-react';

import heroPink from 'container:///mnt/data/src/assets/c8269ba26042a522-image_20261029_214023.webp';
import heroMint from 'container:///mnt/data/src/assets/9a283cb3e2944dbd-image_20261029_214022_1.webp';
import heroBurgundy from 'container:///mnt/data/src/assets/bca90eb7087704df-image_20261029_214022.webp';
import bodyButterImg from 'container:///mnt/data/src/assets/00666057089c37da-image_20261029_205306.webp';
import bodyScrubImg from 'container:///mnt/data/src/assets/1e72298e888833b3-image_20261029_205308.webp';
import hairMistImg from 'container:///mnt/data/src/assets/1233c483a5833484-image_20261029_205311.webp';
import handTubeImg from 'container:///mnt/data/src/assets/641a4153b14d8a2d-image_20261029_205302.webp';
import cleanserImg from 'container:///mnt/data/src/assets/535c9e0d5769bc1e-image_20261029_195249.webp';
import modelCreamImg from 'container:///mnt/data/src/assets/dcc06878d91c7069-image_20261029_193153.webp';
import modelHandsImg from 'container:///mnt/data/src/assets/232b0c816427dfb8-image_20261029_195251.webp';
import galleryOneImg from 'container:///mnt/data/src/assets/630a0e974d7b1df2-image_20261029_195357.webp';
import galleryTwoImg from 'container:///mnt/data/src/assets/9b7bf6c91f01e1ae-image_20261029_195255.webp';
import galleryThreeImg from 'container:///mnt/data/src/assets/5d052a53ccebacba-image_20261029_195250_1.webp';

import visaLogo from 'container:///mnt/data/src/assets/b333d7287b1caf26-image_search_0_visa_logo_official.png';
import mastercardLogo from 'container:///mnt/data/src/assets/da2e0343a5fa0ade-image_search_1_mastercard_logo_official.jpg';
import amexLogo from 'container:///mnt/data/src/assets/221908578e10ea96-image_search_2_american_express_logo_official.jpg';
import paypalLogo from 'container:///mnt/data/src/assets/ca95fb83a8751b8a-image_search_3_paypal_logo_official.png';
import applePayLogo from 'container:///mnt/data/src/assets/4b0241e5fd1b2c87-image_search_4_apple_pay_logo_official.png';
import googlePayLogo from 'container:///mnt/data/src/assets/300ff267e00f4d2a-image_search_5_google_pay_logo_official.png';
import maestroLogo from 'container:///mnt/data/src/assets/6c941151189fc29c-image_search_0_maestro_card_logo_official.png';
import verveLogo from 'container:///mnt/data/src/assets/d3d67aefcd74203b-image_search_1_verve_card_logo_nigeria_official.jpg';
import discoverLogo from 'container:///mnt/data/src/assets/a8a7c152bec9ceb2-image_search_2_discover_card_logo_official.jpg';

type Page = 'home' | 'shop' | 'product' | 'cart' | 'checkout' | 'account' | 'confirmation';
type Lang = 'EN' | 'FR';
type Category = 'all' | 'body' | 'face' | 'hair' | 'other';

type Product = {
  id: string;
  no: string;
  title: string;
  subtitle: string;
  category: Exclude<Category, 'all'>;
  audience: string;
  price: number;
  compareAt: number;
  image: string;
  hover: string;
  rating: number;
  reviews: number;
  description: string;
  ingredients: string[];
  benefits: string[];
  usage: string;
  size: string;
};

type Bundle = {
  id: string;
  title: string;
  subtitle: string;
  price: number;
  compareAt: number;
  save: number;
  image: string;
  items: string[];
};

type CartMap = Record<string, number>;

const PRODUCTS: Product[] = [
  {
    id: 'radiant-tint-serum',
    no: 'N°01',
    title: 'Radiant Tint Serum',
    subtitle: 'A skin-first veil with a lit-from-within finish.',
    category: 'face',
    audience: 'for face',
    price: 42,
    compareAt: 49,
    image: heroPink,
    hover: heroPink,
    rating: 4.9,
    reviews: 412,
    description: 'A featherlight tint serum that evens, hydrates and leaves skin looking rested. The shade adapts softly while squalane and hyaluronic acid keep the finish supple, never mask-like.',
    ingredients: ['Squalane 10%', 'Hyaluronic Acid · 3 weights', 'Niacinamide 4%', 'Panthenol 5%'],
    benefits: ['72-hour hydration feel', 'Blurs without covering', 'No fragrance, pH 5.5'],
    usage: 'Warm two drops between fingertips and press over moisturised skin. Layer only where you want more coverage.',
    size: '30 ml',
  },
  {
    id: 'cica-repair-cream',
    no: 'N°02',
    title: 'Cica Repair Cream',
    subtitle: 'A calm, cushioned cream for reactive days.',
    category: 'face',
    audience: 'for face',
    price: 38,
    compareAt: 45,
    image: heroMint,
    hover: heroMint,
    rating: 4.8,
    reviews: 356,
    description: 'A barrier-first cream built around Centella and a ceramide complex. It comforts tightness, supports recovery after actives and leaves a soft, non-greasy seal.',
    ingredients: ['Cica Centella 80%', 'Ceramides NP / AP / EOP', 'Panthenol 5%', 'Squalane 10%'],
    benefits: ['Supports the skin barrier', 'Calms visible redness', 'Vegan and cruelty-free'],
    usage: 'Apply a pea-sized amount morning and evening as the final skincare step. Press gently over areas that feel sensitive.',
    size: '50 ml',
  },
  {
    id: 'egf-nad-renewal',
    no: 'N°03',
    title: 'EGF NAD+ Renewal',
    subtitle: 'A concentrated night ritual for firmness and glow.',
    category: 'face',
    audience: 'for face',
    price: 68,
    compareAt: 80,
    image: heroBurgundy,
    hover: heroBurgundy,
    rating: 4.9,
    reviews: 289,
    description: 'A refined renewal concentrate with EGF, NAD-inspired technology and collagen extract. Designed for evenings when skin looks tired and needs a more deliberate ritual.',
    ingredients: ['EGF complex', 'NAD-inspired complex', 'Collagen Extract', 'Niacinamide 4%'],
    benefits: ['Improves the look of firmness', 'Supports overnight renewal', 'Silky, fast-absorbing finish'],
    usage: 'Use three drops in the evening after cleansing. Follow with Cica Repair Cream and avoid layering with strong exfoliants.',
    size: '30 ml',
  },
  {
    id: 'coconut-body-butter',
    no: 'N°04',
    title: 'Coconut Body Butter',
    subtitle: 'Whipped moisture with a clean coconut softness.',
    category: 'body',
    audience: 'for body',
    price: 28,
    compareAt: 33,
    image: bodyButterImg,
    hover: modelCreamImg,
    rating: 4.9,
    reviews: 518,
    description: 'A dense yet fast-melting body butter that turns daily moisturising into a spa-like pause. Coconut, squalane and ceramides leave skin smooth without a heavy residue.',
    ingredients: ['Coconut butter', 'Squalane 10%', 'Ceramides NP / AP / EOP', 'Panthenol 5%'],
    benefits: ['Deep comfort for dry areas', 'Soft sheen, not sticky', 'Fragrance-free formula'],
    usage: 'Massage over damp skin after showering, focusing on elbows, knees and shoulders. A little goes a long way.',
    size: '200 ml',
  },
  {
    id: 'coconut-body-scrub',
    no: 'N°05',
    title: 'Body Scrub Coconut',
    subtitle: 'A polished reset for smooth, touchable skin.',
    category: 'body',
    audience: 'for body',
    price: 8,
    compareAt: 12,
    image: bodyScrubImg,
    hover: modelHandsImg,
    rating: 4.7,
    reviews: 441,
    description: 'A gentle coconut scrub that lifts dullness and leaves skin ready for body butter. Fine exfoliating particles rinse clean while oils cushion the skin.',
    ingredients: ['Coconut shell polish', 'Sugarcane squalane', 'Panthenol 5%', 'Vitamin E'],
    benefits: ['Smooths rough texture', 'Preps skin for moisture', 'Rinses without residue'],
    usage: 'Use two or three times weekly on wet skin. Massage in circles, rinse, then follow with Coconut Body Butter.',
    size: '180 ml',
  },
  {
    id: 'silk-hair-mist',
    no: 'N°06',
    title: 'Silk Hair Mist',
    subtitle: 'A weightless shine mist for hair and scalp comfort.',
    category: 'hair',
    audience: 'for hair',
    price: 24,
    compareAt: 29,
    image: hairMistImg,
    hover: modelHandsImg,
    rating: 4.8,
    reviews: 233,
    description: 'A fine mist that refreshes lengths, softens flyaways and adds a quiet shine. Panthenol and hyaluronic acid help hair feel hydrated without flattening movement.',
    ingredients: ['Panthenol 5%', 'Hyaluronic Acid', 'Squalane 10%', 'Centella extract'],
    benefits: ['Softens and detangles', 'Adds light-reflecting shine', 'No heavy perfume'],
    usage: 'Mist over dry or towel-dried hair from mid-lengths to ends. Comb through and style as usual.',
    size: '100 ml',
  },
  {
    id: 'gentle-cloud-cleanser',
    no: 'N°07',
    title: 'Gentle Cloud Cleanser',
    subtitle: 'A pH-balanced cleanse that respects the barrier.',
    category: 'face',
    audience: 'for face',
    price: 26,
    compareAt: 31,
    image: cleanserImg,
    hover: galleryOneImg,
    rating: 4.8,
    reviews: 367,
    description: 'A cloud-soft gel cleanser that removes sunscreen and daily impurities while keeping skin comfortable. No tight after-feel, no unnecessary fragrance.',
    ingredients: ['Panthenol 5%', 'Ceramides NP / AP / EOP', 'Centella 80%', 'pH 5.5 system'],
    benefits: ['Cleans without stripping', 'Suitable for morning and evening', 'Paraben-free and vegan'],
    usage: 'Massage over damp skin for sixty seconds, then rinse with lukewarm water. Follow with serum and cream.',
    size: '150 ml',
  },
  {
    id: 'silk-hand-creme',
    no: 'N°08',
    title: 'Silk Hand Crème',
    subtitle: 'A hand ritual for bags, desks and bedside tables.',
    category: 'other',
    audience: 'for hands',
    price: 16,
    compareAt: 19,
    image: handTubeImg,
    hover: galleryThreeImg,
    rating: 4.7,
    reviews: 198,
    description: 'A precise hand crème that absorbs quickly and leaves hands soft, smooth and ready to touch. Ceramides and panthenol support skin through frequent washing.',
    ingredients: ['Ceramides NP / AP / EOP', 'Panthenol 5%', 'Squalane 10%', 'Collagen Extract'],
    benefits: ['Fast-absorbing comfort', 'Supports nails and cuticles', 'Travel-friendly ritual'],
    usage: 'Apply a pea-sized amount to hands and cuticles whenever skin feels dry. Reapply after washing.',
    size: '75 ml',
  },
];

const BUNDLES: Bundle[] = [
  {
    id: 'bundle-rituel-matin',
    title: 'Le Rituel Matin',
    subtitle: 'Cleanse, tint and protect the day ahead.',
    price: 128,
    compareAt: 148,
    save: 20,
    image: galleryOneImg,
    items: ['Gentle Cloud Cleanser', 'Radiant Tint Serum', 'Cica Repair Cream'],
  },
  {
    id: 'bundle-rituel-nuit',
    title: 'Le Rituel Nuit',
    subtitle: 'Renew, repair and wake to calmer skin.',
    price: 145,
    compareAt: 170,
    save: 25,
    image: galleryTwoImg,
    items: ['EGF NAD+ Renewal', 'Cica Repair Cream', 'Silk Hand Crème'],
  },
  {
    id: 'bundle-rituel-complet',
    title: 'Le Rituel Complet',
    subtitle: 'The full Maison Velle ritual, face, body and hair.',
    price: 320,
    compareAt: 380,
    save: 60,
    image: galleryThreeImg,
    items: ['All eight Maison Velle essentials', 'Priority concierge fitting', 'Le Marais atelier pouch'],
  },
];

const ALL_ITEMS: Record<string, { title: string; price: number; compareAt: number; image: string; audience: string }> = {
  ...Object.fromEntries(PRODUCTS.map((p) => [p.id, { title: p.title, price: p.price, compareAt: p.compareAt, image: p.image, audience: p.audience }])),
  ...Object.fromEntries(BUNDLES.map((b) => [b.id, { title: b.title, price: b.price, compareAt: b.compareAt, image: b.image, audience: 'bundle' }])),
};

const INGREDIENTS = [
  ['Squalane 10%', 'Sugarcane · 72h comfort'],
  ['Hyaluronic Acid', '3 weights · deep hydration'],
  ['Ceramides', 'NP / AP / EOP · barrier care'],
  ['Panthenol 5%', 'Soothes and softens'],
  ['Niacinamide 4%', 'Tone and clarity'],
  ['Cica Centella 80%', 'Calm for reactive skin'],
  ['EGF + NAD', 'Night renewal ritual'],
  ['Collagen Extract', 'Supple, bouncy feel'],
];

const CURRENCIES: Record<string, { rate: number; locale: string }> = {
  USD: { rate: 1, locale: 'en-US' },
  EUR: { rate: 0.92, locale: 'fr-FR' },
  GBP: { rate: 0.79, locale: 'en-GB' },
  NGN: { rate: 1550, locale: 'en-NG' },
  CAD: { rate: 1.36, locale: 'en-CA' },
  AUD: { rate: 1.52, locale: 'en-AU' },
  JPY: { rate: 151, locale: 'ja-JP' },
  INR: { rate: 83, locale: 'en-IN' },
  ZAR: { rate: 18, locale: 'en-ZA' },
  CHF: { rate: 0.88, locale: 'de-CH' },
};

const COUNTRIES = [
  { code: 'US', name: 'United States', dial: '+1', currency: 'USD' },
  { code: 'FR', name: 'France', dial: '+33', currency: 'EUR' },
  { code: 'NG', name: 'Nigeria', dial: '+234', currency: 'NGN' },
  { code: 'GB', name: 'United Kingdom', dial: '+44', currency: 'GBP' },
  { code: 'CA', name: 'Canada', dial: '+1', currency: 'CAD' },
  { code: 'AU', name: 'Australia', dial: '+61', currency: 'AUD' },
  { code: 'JP', name: 'Japan', dial: '+81', currency: 'JPY' },
  { code: 'IN', name: 'India', dial: '+91', currency: 'INR' },
  { code: 'ZA', name: 'South Africa', dial: '+27', currency: 'ZAR' },
  { code: 'CH', name: 'Switzerland', dial: '+41', currency: 'CHF' },
];

const DISCOUNTS: Record<string, number> = { VELLE20: 20, FIRST10: 10, GLOW15: 15, PARIS25: 25 };

const COPY = {
  EN: {
    catalog: 'CATALOG',
    about: 'ABOUT US',
    reviews: 'REVIEWS',
    contact: 'CONTACT US',
    hero: 'Cosmetics for the whole body. For every body.',
    missionLabel: 'Brand Mission',
    mission: 'The brand’s goal is to give a feeling of luxury spa care without being over the top. We want to focus on the skincare experience and packaging should not be distracting.',
    learn: 'Learn more',
    products: 'Products',
    shopNow: 'Buy now',
    addBag: 'Add to bag',
    whatsInside: 'What’s Inside',
    bundles: 'Bundles',
    pricing: 'Pricing',
    cart: 'Your bag',
    checkout: 'Checkout',
    account: 'Account',
    search: 'Search Maison Velle',
  },
  FR: {
    catalog: 'CATALOGUE',
    about: 'À PROPOS',
    reviews: 'AVIS',
    contact: 'CONTACT',
    hero: 'Des cosmétiques pour tout le corps. Pour chaque corps.',
    missionLabel: 'Mission de la marque',
    mission: 'L’objectif de la marque est d’offrir une sensation de soin spa luxueux sans en faire trop. Nous voulons nous concentrer sur l’expérience de soin et l’emballage ne doit pas distraire.',
    learn: 'En savoir plus',
    products: 'Produits',
    shopNow: 'Acheter',
    addBag: 'Ajouter au panier',
    whatsInside: 'Ce qui est à l’intérieur',
    bundles: 'Coffrets',
    pricing: 'Tarifs',
    cart: 'Votre panier',
    checkout: 'Paiement',
    account: 'Compte',
    search: 'Rechercher Maison Velle',
  },
} as const;

const REVIEWS = [
  { name: 'Amara L.', product: 'Coconut Body Butter', text: 'The texture melts in like a spa treatment, but my skin still feels comfortable hours later. It has become the last step of my evening ritual.' },
  { name: 'Sofia M.', product: 'Radiant Tint Serum', text: 'It evens my skin without looking like makeup. Two drops, moisturiser underneath, and I look rested even on early mornings.' },
  { name: 'Chloé D.', product: 'Cica Repair Cream', text: 'My barrier was unhappy after too many actives. This felt calm, cushioned and simple — exactly what I needed.' },
];

async function parseApi(response: Response) {
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload.error) throw new Error(payload.error || `Request failed (${response.status})`);
  return payload.data;
}

async function listRecords(collection: string) {
  const response = await fetch("actions", {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ action: "records.list", args: { collection } }),
  });
  return parseApi(response);
}

async function createRecord(collection: string, value: Record<string, unknown>, idempotencyKey?: string) {
  const response = await fetch("actions", {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ action: "records.create", args: { collection, value, idempotency_key: idempotencyKey } }),
  });
  return parseApi(response);
}

async function replaceRecord(collection: string, id: string, value: Record<string, unknown>) {
  const response = await fetch("actions", {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ action: "records.replace", args: { collection, id, value } }),
  });
  return parseApi(response);
}

async function deleteRecord(collection: string, id: string) {
  const response = await fetch("actions", {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ action: "records.delete", args: { collection, id } }),
  });
  return parseApi(response);
}

function detectCard(number: string) {
  const n = number.replace(/\D/g, '');
  if (/^4/.test(n)) return 'Visa';
  if (/^(5[1-5]|2[2-7])/.test(n)) return 'Mastercard';
  if (/^3[47]/.test(n)) return 'Amex';
  if (/^(5018|5020|5038|5893|6304|6759|6761|6762|6763)/.test(n)) return 'Maestro';
  if (/^(5060|6500)/.test(n)) return 'Verve';
  if (/^(6011|65|64[4-9])/.test(n)) return 'Discover';
  return '';
}

function luhnValid(number: string) {
  const n = number.replace(/\D/g, '');
  if (n.length < 13 || n.length > 19) return false;
  let sum = 0;
  let alt = false;
  for (let i = n.length - 1; i >= 0; i -= 1) {
    let d = Number(n[i]);
    if (alt) {
      d *= 2;
      if (d > 9) d -= 9;
    }
    sum += d;
    alt = !alt;
  }
  return sum % 10 === 0;
}

function GoogleMark() {
  return (
    <svg aria-hidden="true" viewBox="0 0 24 24" className="h-5 w-5 shrink-0">
      <path fill="#4285F4" d="M23.5 12.3c0-.9-.1-1.5-.3-2.2H12v4.3h6.5c-.1 1.1-.8 2.7-2.4 3.8l3.7 2.9c2.3-2.1 3.7-5.2 3.7-8.8z" />
      <path fill="#34A853" d="M12 24c3.2 0 5.9-1.1 7.9-2.9l-3.7-2.9c-1 .7-2.4 1.2-4.2 1.2-3.2 0-5.9-2.2-6.9-5.1L1.3 17.2C3.3 21.2 7.3 24 12 24z" />
      <path fill="#FBBC05" d="M5.1 14.3c-.2-.7-.4-1.5-.4-2.3s.1-1.6.4-2.3L1.3 6.8C.5 8.4 0 10.1 0 12s.5 3.6 1.3 5.2l3.8-2.9z" />
      <path fill="#EA4335" d="M12 4.7c1.8 0 3 .8 3.7 1.4l3.3-3.2C17.9 1.1 15.2 0 12 0 7.3 0 3.3 2.8 1.3 6.8l3.8 2.9c1-2.9 3.7-5 6.9-5z" />
    </svg>
  );
}

export default function App() {
  const [page, setPage] = useState<Page>('home');
  const [selectedId, setSelectedId] = useState(PRODUCTS[0].id);
  const [heroIndex, setHeroIndex] = useState(0);
  const [cart, setCart] = useState<CartMap>({});
  const [cartRecordIds, setCartRecordIds] = useState<Record<string, string>>({});
  const [backendNote, setBackendNote] = useState('Connecting to your saved Maison Velle bag…');
  const [lang, setLang] = useState<Lang>('EN');
  const [currency, setCurrency] = useState('USD');
  const [country, setCountry] = useState('US');
  const [theme, setTheme] = useState<'light' | 'dark'>('light');
  const [toast, setToast] = useState('');
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState<Category>('all');
  const [sort, setSort] = useState('featured');
  const [galleryImage, setGalleryImage] = useState(PRODUCTS[0].image);
  const [selectedBundles, setSelectedBundles] = useState<string[]>(['bundle-rituel-matin']);
  const [offers, setOffers] = useState<string[]>(['samples']);
  const [assistantOpen, setAssistantOpen] = useState(false);
  const [assistantInput, setAssistantInput] = useState('');
  const [assistantPhase, setAssistantPhase] = useState<'idle' | 'thinking' | 'analyzing'>('idle');
  const [messages, setMessages] = useState([{ role: 'assistant', text: 'Bonjour. I can help you choose a ritual by skin goal, body area or budget.' }]);
  const [discountInput, setDiscountInput] = useState('');
  const [appliedDiscount, setAppliedDiscount] = useState<{ code: string; pct: number } | null>(null);
  const [checkout, setCheckout] = useState({
    email: '', name: '', card: '', expiry: '', cvc: '', phone: '+1 ', address: '', city: '', postal: '', country: 'US',
  });
  const [checkoutErrors, setCheckoutErrors] = useState<Record<string, string>>({});
  const [order, setOrder] = useState<{ id: string; total: number; method: string } | null>(null);
  const [account, setAccount] = useState({ name: '', email: '', phone: '', password: '' });
  const [accountDone, setAccountDone] = useState(false);
  const [currentUser, setCurrentUser] = useState<{ name: string; email: string; id?: string; created_at?: string } | null>(null);
  const [authMode, setAuthMode] = useState<'signup' | 'signin'>('signup');
  const [verifyModal, setVerifyModal] = useState('');
  const [dashTab, setDashTab] = useState<'orders' | 'profile' | 'addresses' | 'wishlist'>('orders');
  const [userOrders, setUserOrders] = useState<any[]>([]);
  const [expandedOrder, setExpandedOrder] = useState<string>('');
  const [receiptOrder, setReceiptOrder] = useState<any | null>(null);
  const [wishlist, setWishlist] = useState<string[]>([]);
  const [addresses, setAddresses] = useState<any[]>([]);
  const [newAddress, setNewAddress] = useState({ label: 'Home', address: '', city: '', postal: '', country: 'US' });
  const carouselRef = useRef<HTMLDivElement | null>(null);
  const [busy, setBusy] = useState(false);
  const toastTimer = useRef<number | null>(null);

  const copy = COPY[lang];
  const selectedProduct = PRODUCTS.find((p) => p.id === selectedId) || PRODUCTS[0];
  const cartEntries = Object.entries(cart).filter(([, qty]) => qty > 0 && ALL_ITEMS).map(([id, qty]) => ({ id, qty, item: ALL_ITEMS[id] })).filter((x) => x.item);
  const cartCount = cartEntries.reduce((sum, x) => sum + x.qty, 0);
  const subtotal = cartEntries.reduce((sum, x) => sum + x.item.price * x.qty, 0);
  const compareSubtotal = cartEntries.reduce((sum, x) => sum + x.item.compareAt * x.qty, 0);
  const discountAmount = appliedDiscount ? subtotal * (appliedDiscount.pct / 100) : 0;
  const shipping = subtotal === 0 || subtotal - discountAmount >= 75 ? 0 : 8;
  const total = Math.max(0, subtotal - discountAmount + shipping);

  const money = (usd: number) => {
    const c = CURRENCIES[currency] || CURRENCIES.USD;
    return new Intl.NumberFormat(c.locale, { style: 'currency', currency, maximumFractionDigits: currency === 'JPY' || currency === 'NGN' ? 0 : 2 }).format(usd * c.rate);
  };

  const showToast = (text: string) => {
    setToast(text);
    if (toastTimer.current) window.clearTimeout(toastTimer.current);
    toastTimer.current = window.setTimeout(() => setToast(''), 3400);
  };

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
  }, [theme]);

  useEffect(() => {
    const timer = window.setInterval(() => setHeroIndex((v) => (v + 1) % 3), 5000);
    return () => window.clearInterval(timer);
  }, []);

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        const data = await listRecords('cart_items');
        if (!mounted) return;
        const nextCart: CartMap = {};
        const nextIds: Record<string, string> = {};
        for (const record of data.records || []) {
          const productId = record.value?.productId;
          const qty = Number(record.value?.qty || 0);
          if (productId && ALL_ITEMS[productId] && qty > 0) {
            nextCart[productId] = qty;
            nextIds[productId] = record.id;
          }
        }
        setCart(nextCart);
        setCartRecordIds(nextIds);
        setBackendNote('Saved bag connected. Your bag is stored in Maison Velle records.');
      } catch {
        if (mounted) setBackendNote('Saved bag is unavailable in this preview. You can still browse and build a bag for this session.');
      }
    })();
    return () => { mounted = false; };
  }, []);

  useEffect(() => {
    setGalleryImage(selectedProduct.image);
  }, [selectedProduct]);

  useEffect(() => {
    const el = carouselRef.current; if (!el) return;
    const t = window.setInterval(() => { if (el.scrollLeft + el.clientWidth >= el.scrollWidth - 10) el.scrollTo({ left: 0, behavior: 'smooth' }); else el.scrollBy({ left: 220, behavior: 'smooth' }); }, 2600);
    return () => window.clearInterval(t);
  }, [page]);

  const go = (next: Page) => {
    setPage(next);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const goSection = (id: string) => {
    if (page !== 'home') setPage('home');
    window.setTimeout(() => document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' }), page === 'home' ? 0 : 80);
  };

  const openProduct = (product: Product) => {
    setSelectedId(product.id);
    setGalleryImage(product.image);
    go('product');
  };

  const syncCartItem = async (productId: string, qty: number) => {
    try {
      const recordId = cartRecordIds[productId];
      if (qty <= 0) {
        if (recordId) await deleteRecord('cart_items', recordId);
        setCartRecordIds((prev) => { const next = { ...prev }; delete next[productId]; return next; });
        return;
      }
      if (recordId) {
        await replaceRecord('cart_items', recordId, { productId, qty });
      } else {
        const created = await createRecord('cart_items', { productId, qty }, `cart-${productId}-${qty}`);
        if (created?.id) setCartRecordIds((prev) => ({ ...prev, [productId]: created.id }));
      }
      setBackendNote('Saved bag connected. Changes are stored in Maison Velle records.');
    } catch {
      setBackendNote('Saved bag is unavailable in this preview. This session bag is still ready to use.');
    }
  };

  const addToCart = (id: string, qty = 1, silent = false) => {
    const nextQty = (cart[id] || 0) + qty;
    setCart((prev) => ({ ...prev, [id]: nextQty }));
    void syncCartItem(id, nextQty);
    if (!silent) showToast(`${ALL_ITEMS[id].title} added to your bag.`);
  };

  const setQty = (id: string, qty: number) => {
    setCart((prev) => {
      const next = { ...prev };
      if (qty <= 0) delete next[id]; else next[id] = qty;
      return next;
    });
    void syncCartItem(id, qty);
  };

  const addSelectedBundles = () => {
    if (!selectedBundles.length) {
      showToast('Select at least one bundle first.');
      return;
    }
    selectedBundles.forEach((id) => addToCart(id, 1, true));
    showToast(`${selectedBundles.length} bundle${selectedBundles.length > 1 ? 's' : ''} added to your bag.`);
    go('cart');
  };

  const filteredProducts = useMemo(() => {
    let list = PRODUCTS.filter((p) => (category === 'all' || p.category === category) && `${p.title} ${p.subtitle} ${p.ingredients.join(' ')}`.toLowerCase().includes(query.toLowerCase()));
    if (sort === 'price-low') list = [...list].sort((a, b) => a.price - b.price);
    if (sort === 'price-high') list = [...list].sort((a, b) => b.price - a.price);
    if (sort === 'rating') list = [...list].sort((a, b) => b.rating - a.rating);
    return list;
  }, [category, query, sort]);

  const applyDiscount = () => {
    const code = discountInput.trim().toUpperCase();
    if (!code) return;
    if (DISCOUNTS[code]) {
      setAppliedDiscount({ code, pct: DISCOUNTS[code] });
      showToast(`${code} applied — ${DISCOUNTS[code]}% saved.`);
    } else {
      showToast('That code is not active. Try VELLE20 or PARIS25.');
    }
  };

  const updateCheckout = (field: string, value: string) => {
    let next = value;
    if (field === 'card') {
      const digits = value.replace(/\D/g, '').slice(0, 19);
      next = digits.replace(/(.{4})/g, '$1 ').trim();
    }
    if (field === 'expiry') {
      const digits = value.replace(/\D/g, '').slice(0, 4);
      next = digits.length > 2 ? `${digits.slice(0, 2)}/${digits.slice(2)}` : digits;
    }
    if (field === 'cvc') next = value.replace(/\D/g, '').slice(0, 4);
    setCheckout((prev) => ({ ...prev, [field]: next }));
    setCheckoutErrors((prev) => ({ ...prev, [field]: '' }));
  };

  const changeCheckoutCountry = (code: string) => {
    const found = COUNTRIES.find((c) => c.code === code) || COUNTRIES[0];
    setCheckout((prev) => ({ ...prev, country: code, phone: found.dial + ' ' }));
  };

  const validateCheckout = () => {
    const errors: Record<string, string> = {};
    if (!/^\S+@\S+\.\S+$/.test(checkout.email)) errors.email = 'Enter a valid email.';
    if (checkout.name.trim().length < 2) errors.name = 'Enter the name on card.';
    if (!luhnValid(checkout.card)) errors.card = 'Enter a valid card number.';
    const match = checkout.expiry.match(/^(\d{2})\/(\d{2})$/);
    if (!match || Number(match[1]) < 1 || Number(match[1]) > 12) errors.expiry = 'Use MM/YY.';
    else {
      const expiryDate = new Date(2000 + Number(match[2]), Number(match[1]), 0, 23, 59, 59);
      if (expiryDate < new Date()) errors.expiry = 'This card has expired.';
    }
    if (checkout.cvc.length < 3) errors.cvc = 'Enter the security code.';
    if (checkout.phone.replace(/\D/g, '').length < 7) errors.phone = 'Enter a valid phone number.';
    if (checkout.address.trim().length < 5) errors.address = 'Enter your billing address.';
    if (checkout.city.trim().length < 2) errors.city = 'Enter your city.';
    if (checkout.postal.trim().length < 3) errors.postal = 'Enter your postal code.';
    setCheckoutErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const loadUserOrders = async (email: string) => {
    try {
      const data = await listRecords('orders');
      const filtered = (data.records || []).filter((r: any) => (r.value?.email || '').toLowerCase() === email.toLowerCase()).map((r: any) => ({ id: r.id, created_at: r.created_at, ...r.value }));
      setUserOrders(filtered);
      return filtered;
    } catch { setUserOrders([]); return []; }
  };
  const downloadReceipt = (ord: any) => {
    const lines = [`MAISON VELLE — RECEIPT`, `Order: ${ord.orderNumber || ord.id}`, `Date: ${ord.created_at ? new Date(ord.created_at).toLocaleString() : new Date().toLocaleString()}`, `Email: ${ord.email || currentUser?.email || checkout.email}`, `Tracking: ${ord.trackingNumber || 'MV-TRK-000000'}`, `Carrier: ${ord.carrier || 'DHL Paris'} · ETA: ${ord.eta || '3-5 business days'}`, `Payment: ${ord.paymentMethod || 'Card'} ****${ord.cardLast4 || ''}`, `Billing: ${ord.billingAddress || checkout.address}, ${ord.city || checkout.city} ${ord.postal || checkout.postal}`, ``, `ITEMS`, ...(ord.items || []).map((i: any) => `${i.title} x${i.qty} — $${(i.unitPrice * i.qty).toFixed(2)}`), ``, `Subtotal: $${Number(ord.subtotal || 0).toFixed(2)}`, `Discount: -$${Number(ord.discountAmount || 0).toFixed(2)} ${ord.discount?.code ? '(' + ord.discount.code + ')' : ''}`, `Shipping: $${Number(ord.shipping || 0).toFixed(2)}`, `Total: $${Number(ord.total || 0).toFixed(2)} ${ord.currency || currency}`];
    const blob = new Blob([lines.join('\n')], { type: 'text/plain' });
    const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = `maison-velle-receipt-${ord.orderNumber || ord.id}.txt`; a.click(); URL.revokeObjectURL(url);
  };
  const payWithCard = async () => {
    if (!cartEntries.length) {
      showToast('Your bag is empty. Add a ritual first.');
      return;
    }
    if (!validateCheckout()) {
      showToast('Please review the highlighted payment fields.');
      return;
    }
    setBusy(true);
    try {
      const brand = detectCard(checkout.card) || 'Card';
      const orderNumber = `MV-${Date.now().toString().slice(-6)}`;
      const trackingNumber = `MV-TRK-${Date.now().toString().slice(-6)}`;
      const created = await createRecord('orders', {
        orderNumber, trackingNumber, carrier: 'DHL Paris', eta: '3-5 business days', statusStep: 0,
        items: cartEntries.map((x) => ({ productId: x.id, title: x.item.title, qty: x.qty, unitPrice: x.item.price, imageId: x.id })),
        subtotal,
        discount: appliedDiscount,
        discountAmount,
        shipping,
        total,
        currency,
        email: currentUser?.email || checkout.email,
        country: checkout.country,
        billingAddress: checkout.address, city: checkout.city, postal: checkout.postal, phone: checkout.phone,
        paymentMethod: brand,
        cardLast4: checkout.card.replace(/\D/g, '').slice(-4),
        offers,
        status: 'Processing',
      }, `order-${Date.now()}`);
      const receiptObj = { id: created?.id || orderNumber, orderNumber, trackingNumber, carrier: 'DHL Paris', eta: '3-5 business days', status: 'Processing', items: cartEntries.map((x) => ({ productId: x.id, title: x.item.title, qty: x.qty, unitPrice: x.item.price })), subtotal, discount: appliedDiscount, discountAmount, shipping, total, currency, email: currentUser?.email || checkout.email, paymentMethod: brand, cardLast4: checkout.card.replace(/\D/g, '').slice(-4), billingAddress: checkout.address, city: checkout.city, postal: checkout.postal, created_at: new Date().toISOString() };
      setReceiptOrder(receiptObj);
      showToast(`Receipt sent to ${receiptObj.email}`);
      window.setTimeout(() => showToast('Order confirmation email sent'), 1800);
      for (const entry of cartEntries) {
        const recordId = cartRecordIds[entry.id];
        if (recordId) await deleteRecord('cart_items', recordId);
      }
      setCart({});
      setCartRecordIds({});
      setOrder({ id: created?.id || `MV-${Date.now().toString().slice(-6)}`, total, method: brand });
      go('confirmation');
    } catch (error) {
      showToast(error instanceof Error ? `Order could not be saved: ${error.message}` : 'Order could not be saved. Please try again.');
    } finally {
      setBusy(false);
    }
  };

  const submitAccount = async () => {
    if (authMode === 'signin') {
      if (!/^\S+@\S+\.\S+$/.test(account.email)) { showToast('Enter a valid email to sign in.'); return; }
      const user = { name: account.name.trim() || account.email.split('@')[0], email: account.email.trim(), created_at: new Date().toISOString() };
      setCurrentUser(user); setAccountDone(true); await loadUserOrders(user.email); showToast(`Bonjour, ${user.email}`); return;
    }
    if (account.name.trim().length < 2 || !/^\S+@\S+\.\S+$/.test(account.email)) {
      showToast('Enter your name and a valid email to create your account.');
      return;
    }
    setBusy(true);
    try {
      const created = await createRecord('accounts', { name: account.name.trim(), email: account.email.trim(), phone: account.phone, language: lang, country, currency }, `account-${account.email.trim().toLowerCase()}-${Date.now()}`);
      const user = { name: account.name.trim(), email: account.email.trim(), id: created?.id, created_at: created?.created_at || new Date().toISOString() };
      setVerifyModal(user.email);
      window.setTimeout(() => { setVerifyModal(''); setCurrentUser(user); setAccountDone(true); showToast('Email verified ✓'); loadUserOrders(user.email); }, 2000);
    } catch (error) {
      const user = { name: account.name.trim(), email: account.email.trim(), created_at: new Date().toISOString() };
      setVerifyModal(user.email);
      window.setTimeout(() => { setVerifyModal(''); setCurrentUser(user); setAccountDone(true); showToast('Email verified ✓'); }, 2000);
      if (error) console.warn('Account save unavailable in preview, continuing with verification simulation.');
    } finally {
      setBusy(false);
    }
  };

  const askAssistant = (text?: string) => {
    const prompt = (text ?? assistantInput).trim();
    if (!prompt || assistantPhase !== 'idle') return;
    setMessages((prev) => [...prev, { role: 'user', text: prompt }]);
    setAssistantInput('');
    setAssistantPhase('thinking');
    window.setTimeout(() => {
      setAssistantPhase('analyzing');
      window.setTimeout(() => {
        const lower = prompt.toLowerCase();
        let answer = 'For a simple start, choose Gentle Cloud Cleanser, Radiant Tint Serum in the morning and Cica Repair Cream at night. Add Coconut Body Butter after showers for the full ritual.';
        if (lower.includes('dry') || lower.includes('body')) answer = 'For dry body skin, start with Body Scrub Coconut two or three times a week, then Coconut Body Butter on damp skin. The bundle Le Rituel Complet is the best value if you want face, body and hair together.';
        if (lower.includes('sensitive') || lower.includes('red')) answer = 'For sensitive or reactive skin, keep it minimal: Gentle Cloud Cleanser, Cica Repair Cream and Silk Hand Crème. The formula story is ceramide-led, fragrance-free and pH 5.5.';
        if (lower.includes('bundle') || lower.includes('save') || lower.includes('price')) answer = 'Le Rituel Matin is $128 and saves $20. Le Rituel Nuit is $145 and saves $25. Le Rituel Complet is $320 and saves $60. You can also try VELLE20 at checkout.';
        if (lower.includes('ingredient') || lower.includes('inside')) answer = 'The core story is 12 considered actives: sugarcane squalane 10%, ceramides NP/AP/EOP, panthenol 5%, three-weight hyaluronic acid, niacinamide 4%, Cica Centella 80%, EGF/NAD and collagen extract.';
        setMessages((prev) => [...prev, { role: 'assistant', text: answer }]);
        setAssistantPhase('idle');
      }, 800);
    }, 1200);
  };

  const heroSlides = [heroPink, heroMint, heroBurgundy];

  return (
    <div data-safe-area-inset-root className="min-h-screen bg-[var(--outer)] text-[var(--ink)] overflow-x-clip" style={{ boxSizing: 'border-box', paddingTop: 'var(--safe-area-inset-top)' }}>
      <div className="mx-auto w-full max-w-[1440px] px-2 sm:px-4 lg:px-6 py-3 sm:py-5">
        <div className="rounded-[32px] bg-[var(--surface)] shadow-[var(--shadow)]">
          <header data-safe-area-sticky-top className="sticky z-40 rounded-t-[32px] bg-[color-mix(in_srgb,var(--surface)_92%,transparent)] backdrop-blur-xl" style={{ top: 'var(--safe-area-inset-top)' }}>
            <div className="flex flex-wrap items-center gap-3 px-4 py-4 sm:px-7">
              <button onClick={() => go('home')} className="text-[28px] font-extrabold lowercase leading-none tracking-[-0.06em]" aria-label="Maison Velle home">
                maison velle<span className="text-[#C8A96A]">.</span>
              </button>
              <nav className="order-3 flex w-full items-center gap-2 overflow-x-auto no-scrollbar text-[11px] font-extrabold tracking-[0.16em] sm:order-none sm:w-auto sm:flex-1 sm:justify-center">
                <button onClick={() => go('shop')} className="rounded-full px-3 py-2 hover:bg-[var(--surface-soft)]">{copy.catalog}</button>
                <button onClick={() => goSection('about')} className="rounded-full px-3 py-2 hover:bg-[var(--surface-soft)]">{copy.about}</button>
                <button onClick={() => goSection('reviews')} className="rounded-full px-3 py-2 hover:bg-[var(--surface-soft)]">{copy.reviews}</button>
                <button onClick={() => goSection('contact')} className="rounded-full bg-[var(--accent)] px-4 py-2 text-[var(--accent-ink)] shadow-sm transition hover:-translate-y-0.5">{copy.contact}</button>
              </nav>
              <div className="ml-auto flex items-center gap-2">
                <select value={lang} onChange={(e) => setLang(e.target.value as Lang)} className="hidden h-10 rounded-full border border-[var(--line)] bg-[var(--surface)] px-2 text-xs font-bold sm:block" aria-label="Language">
                  <option value="EN">EN</option>
                  <option value="FR">FR</option>
                </select>
                <select value={currency} onChange={(e) => setCurrency(e.target.value)} className="hidden h-10 rounded-full border border-[var(--line)] bg-[var(--surface)] px-2 text-xs font-bold md:block" aria-label="Currency">
                  {Object.keys(CURRENCIES).map((c) => <option key={c} value={c}>{c}</option>)}
                </select>
                <select value={country} onChange={(e) => { const found = COUNTRIES.find((c) => c.code === e.target.value); setCountry(e.target.value); if (found) setCurrency(found.currency); }} className="hidden h-10 rounded-full border border-[var(--line)] bg-[var(--surface)] px-2 text-xs font-bold lg:block" aria-label="Country">
                  {COUNTRIES.map((c) => <option key={c.code} value={c.code}>{c.code}</option>)}
                </select>
                <button onClick={() => setTheme(theme === 'light' ? 'dark' : 'light')} className="grid h-10 w-10 place-items-center rounded-full border border-[var(--line)] bg-[var(--surface)]" aria-label="Toggle theme">
                  {theme === 'light' ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
                </button>
                <button onClick={() => { if (currentUser) loadUserOrders(currentUser.email); go('account'); }} className="grid h-10 w-10 place-items-center rounded-full border border-[var(--line)] bg-[var(--surface)]" aria-label="Account">
                  <User className="h-4 w-4" />
                </button>
                <button onClick={() => go('cart')} className="relative grid h-10 w-10 place-items-center rounded-full bg-[var(--accent)] text-[var(--accent-ink)]" aria-label="Open bag">
                  <ShoppingBag className="h-4 w-4" />
                  {cartCount > 0 && <span className="absolute -right-1 -top-1 grid h-5 min-w-5 place-items-center rounded-full bg-[#C8A96A] px-1 text-[10px] font-extrabold text-black">{cartCount}</span>}
                </button>
              </div>
            </div>
          </header>

          <main className="px-3 pb-8 sm:px-5 lg:px-7">
            {page === 'home' && (
              <div className="rise-in">
                <section className="relative overflow-hidden rounded-[24px] bg-[var(--beige)]">
                  <div className="relative min-h-[560px] sm:min-h-[620px]">
                    {heroSlides.map((src, index) => (
                      <img key={src} src={src} alt={index === 0 ? 'Radiant Tint Serum' : index === 1 ? 'Cica Repair Cream' : 'EGF NAD+ Renewal'} className={`absolute inset-0 h-full w-full object-cover object-center transition-opacity duration-[1400ms] ${heroIndex === index ? 'opacity-100' : 'opacity-0'}`} />
                    ))}
                    <div className="absolute inset-0 bg-gradient-to-r from-[#E8E0D5]/95 via-[#E8E0D5]/45 to-transparent" />
                    <div className="relative z-10 max-w-[620px] p-6 sm:p-10">
                      <p className="mb-4 inline-flex rounded-full border border-black/10 bg-white/70 px-3 py-1 text-[11px] font-extrabold tracking-[0.18em] text-neutral-900">MAISON VELLE · PARIS</p>
                      <h1 className="max-w-[540px] text-[42px] font-extrabold leading-[0.98] tracking-[-0.045em] text-neutral-950 sm:text-[56px] lg:text-[64px]">{copy.hero}</h1>
                      <p className="mt-5 max-w-[440px] text-sm leading-6 text-neutral-700 sm:text-base">Clean, considered care for face, body and hair — formulated in our Le Marais atelier with twelve active ingredients. Nothing else.</p>
                      <div className="mt-7 flex flex-wrap gap-3">
                        <MagneticButton onClick={() => go('shop')} className="bg-neutral-950 text-white shadow-xl">
                          {copy.catalog} <ArrowRight className="h-4 w-4" />
                        </MagneticButton>
                        <button onClick={() => goSection('inside')} className="rounded-full border border-neutral-950/15 bg-white/80 px-5 py-3 text-sm font-extrabold text-neutral-950 backdrop-blur transition hover:-translate-y-0.5">{copy.whatsInside}</button>
                      </div>
                      <div className="mt-8 flex gap-2">
                        {heroSlides.map((_, index) => (
                          <button key={index} onClick={() => setHeroIndex(index)} aria-label={`Show hero ${index + 1}`} className={`h-2 rounded-full transition-all ${heroIndex === index ? 'w-9 bg-neutral-950' : 'w-2 bg-neutral-950/30 hover:bg-neutral-950/60'}`} />
                        ))}
                      </div>
                    </div>

                    <button onClick={() => openProduct(PRODUCTS[3])} className="absolute right-4 top-5 z-20 w-[190px] rounded-[20px] bg-white p-3 text-left shadow-[0_18px_45px_rgba(0,0,0,0.14)] transition hover:-translate-y-1 sm:right-8 sm:top-8 sm:w-[220px]">
                      <span className="absolute -left-2 -top-2 rounded-full bg-neutral-950 px-2.5 py-1 text-[11px] font-extrabold text-white">-15%</span>
                      <span className="absolute right-3 top-3 grid h-7 w-7 place-items-center rounded-full bg-neutral-950 text-white"><ArrowUpRight className="h-4 w-4" /></span>
                      <img src={bodyButterImg} alt="Coconut Body Butter" className="h-24 w-full rounded-[14px] object-cover" />
                      <span className="mt-3 block text-[11px] font-bold uppercase tracking-[0.14em] text-neutral-500">( for body )</span>
                      <span className="block text-sm font-extrabold text-neutral-950">Coconut Body Butter</span>
                      <span className="mt-1 flex items-baseline gap-2 text-sm"><b>{money(28)}</b><s className="text-neutral-400">{money(33)}</s></span>
                    </button>

                    <div className="absolute bottom-5 left-5 z-20 max-w-[360px] rounded-[20px] bg-white p-4 shadow-[0_18px_45px_rgba(0,0,0,0.13)] sm:bottom-8 sm:left-10">
                      <div className="flex items-start gap-3">
                        <img src={heroMint} alt="Cica Repair Cream" className="h-11 w-11 rounded-full object-cover" />
                        <p className="text-[13px] leading-5 text-neutral-700">“We were inspired by you and wanted to turn everyday care into a special ritual. In the moment of realizing our value, the moment where we are in the first place.”</p>
                      </div>
                    </div>
                  </div>
                </section>

                <section id="about" className="grid gap-6 py-10 md:grid-cols-[180px_1fr] md:py-14">
                  <p className="text-xs font-extrabold uppercase tracking-[0.2em] text-[var(--muted)]">{copy.missionLabel}</p>
                  <div>
                    <p className="max-w-[820px] text-[24px] font-semibold leading-[1.25] tracking-[-0.02em] sm:text-[34px]">{copy.mission}</p>
                    <button onClick={() => goSection('inside')} className="mt-6 rounded-full border border-[var(--ink)] px-5 py-3 text-sm font-extrabold transition hover:bg-[var(--accent)] hover:text-[var(--accent-ink)]">{copy.learn}</button>
                  </div>
                </section>

                <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                  <CategoryTile label="( body )" title="Body Butter" color="var(--lavender)" image={bodyButterImg} onClick={() => { setCategory('body'); go('shop'); }} />
                  <CategoryTile label="( face )" title="Cleanser" color="var(--grey-tile)" image={cleanserImg} onClick={() => { setCategory('face'); go('shop'); }} />
                  <CategoryTile label="( hair )" title="Hair Mist" color="var(--blue-tile)" image={hairMistImg} onClick={() => { setCategory('hair'); go('shop'); }} />
                  <CategoryTile label="( other )" title="Hand Crème" color="var(--beige-tile)" image={handTubeImg} onClick={() => { setCategory('other'); go('shop'); }} />
                </section>

                <section className="relative mt-6 overflow-hidden rounded-[28px] bg-[var(--surface-soft)] px-5 py-8 sm:px-8 lg:px-10">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <span className="rounded-full border border-[var(--line)] bg-[var(--surface)] px-4 py-2 text-xs font-extrabold uppercase tracking-[0.16em]">{copy.products}</span>
                    <div className="flex flex-wrap gap-2 text-xs font-extrabold">
                      {['Aesthetics', 'Comfort', 'Care'].map((label) => (
                        <button key={label} onClick={() => { setQuery(label === 'Care' ? 'ceramides' : ''); go('shop'); }} className="rounded-full border border-[var(--line)] bg-[var(--surface)] px-4 py-2 transition hover:-translate-y-0.5">{label}</button>
                      ))}
                    </div>
                  </div>
                  <div className="relative mt-4 min-h-[300px] sm:min-h-[360px]">
                    <h2 className="shine-text relative z-0 max-w-full text-[clamp(4rem,12vw,10.5rem)] font-extrabold lowercase leading-[0.82] tracking-[-0.075em]">maison<br />velle.</h2>
                    <img src={bodyScrubImg} alt="Body Scrub Coconut" className="absolute right-[8%] top-6 z-10 w-36 rotate-[-8deg] rounded-[24px] object-cover shadow-2xl sm:w-52 lg:w-64" />
                    <div className="relative z-20 mt-8 max-w-[360px] rounded-[22px] bg-[var(--surface)] p-4 shadow-[var(--shadow)] sm:absolute sm:bottom-0 sm:left-0 sm:mt-0">
                      <p className="text-[11px] font-extrabold uppercase tracking-[0.16em] text-[var(--muted)]">( for body )</p>
                      <div className="mt-2 flex items-end justify-between gap-4">
                        <div>
                          <h3 className="text-xl font-extrabold">Body Scrub Coconut</h3>
                          <p className="mt-1 flex items-baseline gap-2"><span className="text-lg font-extrabold">{money(8)}</span><s className="text-sm text-[var(--muted)]">{money(12)}</s><span className="rounded-full bg-[#171512] px-2 py-0.5 text-[10px] font-extrabold text-white">-33%</span></p>
                        </div>
                        <MagneticButton onClick={() => { addToCart('coconut-body-scrub'); go('cart'); }} className="bg-[var(--accent)] text-[var(--accent-ink)] !px-4 !py-2.5 text-xs">{copy.shopNow} <ArrowRight className="h-3.5 w-3.5" /></MagneticButton>
                      </div>
                    </div>
                  </div>
                </section>

                <section id="inside" className="mt-6 rounded-[28px] border border-[var(--line)] bg-[var(--surface)] p-6 sm:p-9">
                  <div className="grid gap-8 lg:grid-cols-2">
                    <div>
                      <p className="text-xs font-extrabold uppercase tracking-[0.2em] text-[var(--muted)]">Ce qui est à l’intérieur / {copy.whatsInside}</p>
                      <h2 className="mt-4 text-[36px] font-extrabold leading-[1.02] tracking-[-0.04em] sm:text-[48px]">Formulated with 12 active ingredients. Nothing else.</h2>
                      <p className="mt-5 max-w-[540px] leading-7 text-[var(--muted)]">Every Maison Velle formula begins with a short, legible ingredient story: barrier lipids, water-binding humectants and calm botanical extracts, balanced at pH 5.5 in our Le Marais atelier.</p>
                    </div>
                    <div className="grid gap-3 sm:grid-cols-2">
                      {[
                        ['Squalane 10%', 'Sugarcane-derived emollient for a cushioned, non-greasy finish.'],
                        ['Ceramides NP / AP / EOP', 'A barrier-mimicking lipid trio for comfort and resilience.'],
                        ['Panthenol 5% + HA', 'Provitamin B5 with three weights of hyaluronic acid.'],
                        ['Niacinamide 4% + Cica 80%', 'Tone, clarity and calm for skin that reacts easily.'],
                        ['EGF · NAD · Collagen', 'A refined night-renewal complex for firmness and bounce.'],
                        ['Clean standards', 'Vegan, cruelty-free, paraben-free, fragrance-free, pH 5.5.'],
                      ].map(([title, text]) => (
                        <div key={title} className="rounded-[18px] bg-[var(--surface-soft)] p-4">
                          <h3 className="font-extrabold">{title}</h3>
                          <p className="mt-1 text-sm leading-6 text-[var(--muted)]">{text}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="no-scrollbar mt-8 flex gap-3 overflow-x-auto pb-1">
                    {INGREDIENTS.map(([title, sub]) => (
                      <button key={title} onClick={() => { setQuery(title.split(' ')[0]); go('shop'); }} className="shrink-0 rounded-full border border-[var(--line)] bg-[var(--surface-soft)] px-5 py-3 text-left transition hover:-translate-y-0.5 hover:bg-[var(--beige)]">
                        <span className="block text-sm font-extrabold">{title}</span>
                        <span className="block text-xs text-[var(--muted)]">{sub}</span>
                      </button>
                    ))}
                  </div>
                </section>

                <section className="mt-6 rounded-[28px] border border-[var(--line)] bg-[var(--surface)] p-6 sm:p-9">
                  <p className="text-xs font-extrabold uppercase tracking-[0.2em] text-[var(--muted)]">Ingredients carousel</p>
                  <div ref={carouselRef} className="no-scrollbar mt-5 flex cursor-grab gap-3 overflow-x-auto pb-2 active:cursor-grabbing">
                    {[['Squalane 10%','Sugarcane • 72h hydration'],['Hyaluronic Acid','3 weights • Deep hydration'],['Niacinamide 4%','Even tone'],['Cica 80%','Soothing'],['Ceramides','Barrier repair'],['Panthenol 5%','Calm'],['EGF + NAD','Night renewal'],['Collagen Extract','Supple bounce']].map(([t,s]) => <button key={t} onClick={() => { setQuery(t.split(' ')[0]); go('shop'); }} className="min-w-[210px] rounded-full border border-[var(--line)] bg-[var(--surface-soft)] px-5 py-4 text-left"><span className="block font-extrabold">{t} • {s.split('•')[0]}</span><span className="text-xs text-[var(--muted)]">{s}</span></button>)}
                  </div>
                  <div className="mt-3 flex justify-center gap-2">{[0,1,2,3].map(i => <span key={i} className={`h-2 rounded-full ${i===0?'w-8 bg-[var(--ink)]':'w-2 bg-[var(--line)]'}`} />)}</div>
                </section>

                <section className="mt-6 rounded-[28px] bg-[var(--surface-soft)] p-6 sm:p-9">
                  <p className="text-xs font-extrabold uppercase tracking-[0.2em] text-[var(--muted)]">Pourquoi MAISON VELLE / Why Maison Velle</p>
                  <h2 className="mt-3 text-[32px] font-extrabold tracking-[-0.04em] sm:text-[42px]">Pourquoi MAISON VELLE / Why</h2>
                  <div className="mt-6 grid gap-4 md:grid-cols-3">
                    {[['Paris ritual','Formulated in our Le Marais atelier in Paris — a calm, considered ritual, never over the top.'],['Lab tested','Dermatologically considered, pH 5.5, vegan, cruelty-free, paraben-free and fragrance-free.'],['Skin first','Twelve active ingredients and nothing else: barrier lipids, humectants and calm botanicals first.']].map(([t,s],i) => <article key={t} className="rounded-[22px] bg-[var(--surface)] p-6"><span className="grid h-11 w-11 place-items-center rounded-full bg-[var(--accent)] text-[var(--accent-ink)]">{i===0?<MapPin className="h-5 w-5"/>:i===1?<ShieldCheck className="h-5 w-5"/>:<Sparkles className="h-5 w-5"/>}</span><h3 className="mt-4 text-xl font-extrabold">{t}</h3><p className="mt-2 leading-7 text-[var(--muted)]">{s}</p></article>)}
                  </div>
                </section>

                <section className="py-10">
                  <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
                    <div>
                      <p className="text-xs font-extrabold uppercase tracking-[0.2em] text-[var(--muted)]">{copy.pricing}</p>
                      <h2 className="mt-2 text-[34px] font-extrabold tracking-[-0.04em] sm:text-[44px]">The ritual shelf</h2>
                    </div>
                    <button onClick={() => go('shop')} className="rounded-full bg-[var(--accent)] px-5 py-3 text-sm font-extrabold text-[var(--accent-ink)] transition hover:-translate-y-0.5">{copy.catalog} <ArrowRight className="inline h-4 w-4" /></button>
                  </div>
                  <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                    {PRODUCTS.slice(0, 8).map((product) => <ProductCard key={product.id} product={product} money={money} onOpen={() => openProduct(product)} onBuy={() => { addToCart(product.id); go('cart'); }} buyLabel={copy.shopNow} />)}
                  </div>
                </section>

                <BundleSection selectedBundles={selectedBundles} setSelectedBundles={setSelectedBundles} offers={offers} setOffers={setOffers} money={money} onAdd={addSelectedBundles} showToast={showToast} />

                <section id="reviews" className="py-10">
                  <div className="mb-6 flex items-end justify-between gap-4">
                    <h2 className="text-[34px] font-extrabold tracking-[-0.04em] sm:text-[44px]">Loved in real rituals</h2>
                    <span className="hidden rounded-full border border-[var(--line)] px-4 py-2 text-xs font-extrabold sm:block">4.9 / 5 average</span>
                  </div>
                  <div className="grid gap-4 md:grid-cols-3">
                    {REVIEWS.map((review) => (
                      <article key={review.name} className="rounded-[22px] bg-[var(--surface-soft)] p-6">
                        <div className="flex gap-1 text-[#C8A96A]">{Array.from({ length: 5 }).map((_, i) => <Star key={i} className="h-4 w-4 fill-current" />)}</div>
                        <p className="mt-4 leading-7 text-[var(--muted)]">“{review.text}”</p>
                        <p className="mt-5 text-sm font-extrabold">{review.name}</p>
                        <p className="text-xs text-[var(--muted)]">{review.product}</p>
                      </article>
                    ))}
                  </div>
                </section>
              </div>
            )}

            {page === 'shop' && (
              <section className="rise-in py-6 sm:py-8">
                <div className="flex flex-wrap items-end justify-between gap-5">
                  <div>
                    <p className="text-xs font-extrabold uppercase tracking-[0.2em] text-[var(--muted)]">Maison Velle</p>
                    <h1 className="mt-2 text-[42px] font-extrabold tracking-[-0.05em] sm:text-[58px]">{copy.catalog}</h1>
                  </div>
                  <label className="flex min-w-[240px] flex-1 items-center gap-2 rounded-full border border-[var(--line)] bg-[var(--surface-soft)] px-4 py-3 sm:max-w-[360px]">
                    <Search className="h-4 w-4 text-[var(--muted)]" />
                    <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder={copy.search} className="w-full bg-transparent text-sm outline-none placeholder:text-[var(--muted)]" />
                    {query && <button onClick={() => setQuery('')} aria-label="Clear search"><X className="h-4 w-4" /></button>}
                  </label>
                </div>
                <div className="mt-7 flex flex-wrap items-center gap-2">
                  {(['all', 'body', 'face', 'hair', 'other'] as Category[]).map((cat) => (
                    <button key={cat} onClick={() => setCategory(cat)} className={`rounded-full px-4 py-2 text-xs font-extrabold uppercase tracking-[0.12em] transition ${category === cat ? 'bg-[var(--accent)] text-[var(--accent-ink)]' : 'border border-[var(--line)] bg-[var(--surface)] hover:-translate-y-0.5'}`}>{cat === 'all' ? 'All' : `( ${cat} )`}</button>
                  ))}
                  <select value={sort} onChange={(e) => setSort(e.target.value)} className="ml-auto rounded-full border border-[var(--line)] bg-[var(--surface)] px-4 py-2 text-xs font-extrabold" aria-label="Sort products">
                    <option value="featured">Featured</option>
                    <option value="price-low">Price · low to high</option>
                    <option value="price-high">Price · high to low</option>
                    <option value="rating">Top rated</option>
                  </select>
                </div>
                <p className="mt-5 text-sm text-[var(--muted)]">{filteredProducts.length} Maison Velle products · prices shown in {currency}</p>
                <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                  {filteredProducts.map((product) => <ProductCard key={product.id} product={product} money={money} onOpen={() => openProduct(product)} onBuy={() => { addToCart(product.id); go('cart'); }} buyLabel={copy.shopNow} />)}
                </div>
                {filteredProducts.length === 0 && (
                  <div className="mt-6 rounded-[24px] bg-[var(--surface-soft)] p-8 text-center">
                    <p className="font-extrabold">No ritual matches that search yet.</p>
                    <button onClick={() => { setQuery(''); setCategory('all'); }} className="mt-4 rounded-full bg-[var(--accent)] px-5 py-3 text-sm font-extrabold text-[var(--accent-ink)]">Reset filters</button>
                  </div>
                )}
                <div className="mt-10"><BundleSection selectedBundles={selectedBundles} setSelectedBundles={setSelectedBundles} offers={offers} setOffers={setOffers} money={money} onAdd={addSelectedBundles} showToast={showToast} /></div>
              </section>
            )}

            {page === 'product' && (
              <section className="rise-in py-6 sm:py-8">
                <button onClick={() => go('shop')} className="mb-6 rounded-full border border-[var(--line)] px-4 py-2 text-xs font-extrabold transition hover:-translate-y-0.5">← {copy.catalog}</button>
                <div className="grid gap-8 lg:grid-cols-[1.05fr_0.95fr]">
                  <div>
                    <div className="relative overflow-hidden rounded-[28px] bg-[var(--surface-soft)]">
                      <img src={galleryImage} alt={selectedProduct.title} className="aspect-[4/5] w-full object-cover" />
                      <span className="absolute left-4 top-4 rounded-full bg-[var(--surface)] px-3 py-1 text-xs font-extrabold">{selectedProduct.no}</span>
                      <span className="absolute right-4 top-4 rounded-full bg-neutral-950 px-3 py-1 text-xs font-extrabold text-white">-{Math.round((1 - selectedProduct.price / selectedProduct.compareAt) * 100)}%</span>
                    </div>
                    <div className="mt-3 grid grid-cols-3 gap-3">
                      {[selectedProduct.image, selectedProduct.hover, selectedProduct.category === 'body' ? modelCreamImg : galleryTwoImg].map((src, i) => (
                        <button key={`${src}-${i}`} onClick={() => setGalleryImage(src)} className={`overflow-hidden rounded-[18px] ring-offset-2 transition ${galleryImage === src ? 'ring-2 ring-[var(--ink)]' : 'hover:-translate-y-0.5'}`}>
                          <img src={src} alt={selectedProduct.title} className="aspect-[4/3] w-full object-cover" />
                        </button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <p className="text-xs font-extrabold uppercase tracking-[0.2em] text-[var(--muted)]">( {selectedProduct.audience} ) · {selectedProduct.size}</p>
                    <h1 className="mt-3 text-[44px] font-extrabold leading-[0.98] tracking-[-0.05em] sm:text-[58px]">{selectedProduct.title}</h1>
                    <p className="mt-3 text-lg text-[var(--muted)]">{selectedProduct.subtitle}</p>
                    <div className="mt-4 flex items-center gap-2 text-sm"><span className="flex text-[#C8A96A]">{Array.from({ length: 5 }).map((_, i) => <Star key={i} className="h-4 w-4 fill-current" />)}</span><b>{selectedProduct.rating}</b><span className="text-[var(--muted)]">({selectedProduct.reviews} reviews)</span></div>
                    <div className="mt-6 flex flex-wrap items-baseline gap-3">
                      <span className="text-[34px] font-extrabold">{money(selectedProduct.price)}</span>
                      <s className="text-lg text-[var(--muted)]">{money(selectedProduct.compareAt)}</s>
                      <span className="rounded-full bg-[var(--beige)] px-3 py-1 text-xs font-extrabold">Sale pricing in {currency}</span>
                    </div>
                    <p className="mt-6 leading-7 text-[var(--muted)]">{selectedProduct.description}</p>
                    <div className="mt-7 flex flex-wrap gap-3">
                      <MagneticButton onClick={() => addToCart(selectedProduct.id)} className="bg-[var(--accent)] text-[var(--accent-ink)]">{copy.addBag} <ShoppingBag className="h-4 w-4" /></MagneticButton>
                      <button onClick={() => { addToCart(selectedProduct.id, 1, true); go('checkout'); }} className="rounded-full border border-[var(--ink)] px-6 py-3.5 text-sm font-extrabold transition hover:-translate-y-0.5 hover:bg-[var(--surface-soft)]">{copy.shopNow} <ArrowRight className="inline h-4 w-4" /></button>
                    </div>
                    <div className="mt-8 grid gap-3 sm:grid-cols-3">
                      {[['Truck', 'Free over $75'], ['RotateCcw', '30-day returns'], ['ShieldCheck', 'Secure checkout']].map(([icon, label]) => (
                        <div key={label} className="rounded-[18px] bg-[var(--surface-soft)] p-4 text-sm font-extrabold">
                          {icon === 'Truck' ? <Truck className="mb-2 h-5 w-5" /> : icon === 'RotateCcw' ? <RotateCcw className="mb-2 h-5 w-5" /> : <ShieldCheck className="mb-2 h-5 w-5" />}{label}
                        </div>
                      ))}
                    </div>
                    <DetailBlock title="What it is made of" items={selectedProduct.ingredients} />
                    <DetailBlock title="Benefits" items={selectedProduct.benefits} />
                    <div className="mt-6 rounded-[22px] bg-[var(--surface-soft)] p-5">
                      <h3 className="font-extrabold">How to use</h3>
                      <p className="mt-2 leading-7 text-[var(--muted)]">{selectedProduct.usage}</p>
                    </div>
                  </div>
                </div>
                <div className="mt-10"><BundleSection selectedBundles={selectedBundles} setSelectedBundles={setSelectedBundles} offers={offers} setOffers={setOffers} money={money} onAdd={addSelectedBundles} showToast={showToast} /></div>
                <section className="mt-10 grid gap-4 md:grid-cols-3">
                  {REVIEWS.map((review) => (
                    <article key={review.name} className="rounded-[22px] border border-[var(--line)] p-6">
                      <div className="flex gap-1 text-[#C8A96A]">{Array.from({ length: 5 }).map((_, i) => <Star key={i} className="h-4 w-4 fill-current" />)}</div>
                      <p className="mt-4 leading-7 text-[var(--muted)]">“{review.text}”</p>
                      <p className="mt-5 text-sm font-extrabold">{review.name} · {selectedProduct.title}</p>
                    </article>
                  ))}
                </section>
              </section>
            )}

            {page === 'cart' && (
              <section className="rise-in py-6 sm:py-8">
                <h1 className="text-[42px] font-extrabold tracking-[-0.05em] sm:text-[58px]">{copy.cart}</h1>
                <p className="mt-2 text-sm text-[var(--muted)]">{backendNote}</p>
                {cartEntries.length === 0 ? (
                  <div className="mt-8 rounded-[28px] bg-[var(--surface-soft)] p-8 text-center sm:p-12">
                    <ShoppingBag className="mx-auto h-10 w-10" />
                    <h2 className="mt-4 text-2xl font-extrabold">Your bag is empty</h2>
                    <p className="mt-2 text-[var(--muted)]">Your bag is waiting for its first ritual. Only products you add with Buy now / Add to Bag will appear here.</p>
                    <button onClick={() => go('shop')} className="mt-6 rounded-full bg-[var(--accent)] px-6 py-3 text-sm font-extrabold text-[var(--accent-ink)]">{copy.catalog}</button>
                  </div>
                ) : (
                  <div className="mt-8 grid gap-6 lg:grid-cols-[1fr_380px]">
                    <div className="space-y-3">
                      {cartEntries.map(({ id, qty, item }) => (
                        <article key={id} className="flex gap-4 rounded-[24px] border border-[var(--line)] bg-[var(--surface)] p-3 sm:p-4">
                          <img src={item.image} alt={item.title} className="h-24 w-20 rounded-[18px] object-cover sm:h-28 sm:w-24" />
                          <div className="min-w-0 flex-1">
                            <p className="text-[11px] font-extrabold uppercase tracking-[0.16em] text-[var(--muted)]">( {item.audience} )</p>
                            <h3 className="mt-1 truncate text-lg font-extrabold">{item.title}</h3>
                            <p className="mt-1 text-sm"><b>{money(item.price)}</b> <s className="text-[var(--muted)]">{money(item.compareAt)}</s></p>
                            <div className="mt-3 flex items-center gap-2">
                              <button onClick={() => setQty(id, qty - 1)} className="grid h-9 w-9 place-items-center rounded-full border border-[var(--line)]" aria-label="Decrease quantity"><Minus className="h-4 w-4" /></button>
                              <span className="w-6 text-center font-extrabold">{qty}</span>
                              <button onClick={() => setQty(id, qty + 1)} className="grid h-9 w-9 place-items-center rounded-full border border-[var(--line)]" aria-label="Increase quantity"><Plus className="h-4 w-4" /></button>
                              <button onClick={() => setQty(id, 0)} className="ml-2 grid h-9 w-9 place-items-center rounded-full bg-[var(--surface-soft)]" aria-label={`Remove ${item.title}`}><Trash2 className="h-4 w-4" /></button>
                            </div>
                          </div>
                          <b className="text-lg">{money(item.price * qty)}</b>
                        </article>
                      ))}
                    </div>
                    <aside className="h-fit rounded-[26px] bg-[var(--surface-soft)] p-6">
                      <h2 className="text-xl font-extrabold">Summary</h2>
                      <SummaryRows subtotal={subtotal} compareSubtotal={compareSubtotal} discountAmount={discountAmount} shipping={shipping} total={total} money={money} appliedDiscount={appliedDiscount} />
                      <button onClick={() => go('checkout')} className="mt-6 w-full rounded-full bg-[var(--accent)] px-6 py-4 text-sm font-extrabold text-[var(--accent-ink)] transition hover:-translate-y-0.5">{copy.checkout} <ArrowRight className="inline h-4 w-4" /></button>
                      <button onClick={() => go('shop')} className="mt-3 w-full rounded-full border border-[var(--line)] bg-[var(--surface)] px-6 py-3 text-sm font-extrabold">Continue shopping</button>
                    </aside>
                  </div>
                )}
              </section>
            )}

            {page === 'checkout' && (
              <section className="rise-in py-6 sm:py-8">
                <h1 className="text-[42px] font-extrabold tracking-[-0.05em] sm:text-[58px]">{copy.checkout}</h1>
                <p className="mt-2 flex items-center gap-2 text-sm text-[var(--muted)]"><Lock className="h-4 w-4" /> Card details are validated in your browser. Only the last four digits are saved with an order record.</p>
                {cartEntries.length === 0 ? (
                  <div className="mt-8 rounded-[28px] bg-[var(--surface-soft)] p-8 text-center">
                    <p className="text-xl font-extrabold">Your bag is empty.</p>
                    <button onClick={() => go('shop')} className="mt-5 rounded-full bg-[var(--accent)] px-6 py-3 text-sm font-extrabold text-[var(--accent-ink)]">Shop Maison Velle</button>
                  </div>
                ) : (
                  <div className="mt-8 grid gap-6 lg:grid-cols-[1fr_400px]">
                    <div className="space-y-6">
                      <section className="rounded-[26px] border border-[var(--line)] bg-[var(--surface)] p-5 sm:p-7">
                        <h2 className="flex items-center gap-2 text-xl font-extrabold"><CreditCard className="h-5 w-5" /> Card payment</h2>
                        <div className="mt-5 grid gap-4 sm:grid-cols-2">
                          <Field label="Email" error={checkoutErrors.email} className="sm:col-span-2">
                            <input value={checkout.email} onChange={(e) => updateCheckout('email', e.target.value)} placeholder="you@example.com" className="checkout-input" />
                          </Field>
                          <Field label="Name on card" error={checkoutErrors.name} className="sm:col-span-2">
                            <input value={checkout.name} onChange={(e) => updateCheckout('name', e.target.value)} placeholder="Full name" className="checkout-input" />
                          </Field>
                          <Field label="Card number" error={checkoutErrors.card} className="sm:col-span-2">
                            <div className="relative">
                              <input value={checkout.card} onChange={(e) => updateCheckout('card', e.target.value)} inputMode="numeric" placeholder="1234 5678 9012 3456" className="checkout-input pr-28" />
                              <span className="absolute right-3 top-1/2 -translate-y-1/2 rounded-full bg-[var(--surface-soft)] px-3 py-1 text-xs font-extrabold">{detectCard(checkout.card) ? `Detected: ${detectCard(checkout.card)}` : 'Card'}</span>
                            </div>
                          </Field>
                          <Field label="Expiry" error={checkoutErrors.expiry}>
                            <input value={checkout.expiry} onChange={(e) => updateCheckout('expiry', e.target.value)} inputMode="numeric" placeholder="MM/YY" className="checkout-input" />
                          </Field>
                          <Field label="CVC" error={checkoutErrors.cvc}>
                            <input value={checkout.cvc} onChange={(e) => updateCheckout('cvc', e.target.value)} inputMode="numeric" placeholder="123" className="checkout-input" />
                          </Field>
                          <Field label="Country" className="sm:col-span-2">
                            <select value={checkout.country} onChange={(e) => changeCheckoutCountry(e.target.value)} className="checkout-input">
                              {COUNTRIES.map((c) => <option key={c.code} value={c.code}>{c.code} — {c.name} ({c.dial})</option>)}
                            </select>
                          </Field>
                          <Field label="Phone" error={checkoutErrors.phone} className="sm:col-span-2">
                            <div className="flex gap-2">
                              <span className="grid min-w-[76px] place-items-center rounded-full bg-[var(--surface-soft)] px-3 text-sm font-extrabold">{(COUNTRIES.find((c) => c.code === checkout.country) || COUNTRIES[0]).code} {(COUNTRIES.find((c) => c.code === checkout.country) || COUNTRIES[0]).dial}</span>
                              <input value={checkout.phone} onChange={(e) => updateCheckout('phone', e.target.value)} placeholder="Phone number" className="checkout-input" />
                            </div>
                          </Field>
                          <Field label="Billing address" error={checkoutErrors.address} className="sm:col-span-2">
                            <input value={checkout.address} onChange={(e) => updateCheckout('address', e.target.value)} placeholder="Street address" className="checkout-input" />
                          </Field>
                          <Field label="City" error={checkoutErrors.city}>
                            <input value={checkout.city} onChange={(e) => updateCheckout('city', e.target.value)} placeholder="City" className="checkout-input" />
                          </Field>
                          <Field label="Postal code" error={checkoutErrors.postal}>
                            <input value={checkout.postal} onChange={(e) => updateCheckout('postal', e.target.value)} placeholder="Postal code" className="checkout-input" />
                          </Field>
                        </div>

                        <button disabled={busy} onClick={payWithCard} className="mt-7 w-full rounded-full bg-[var(--accent)] px-6 py-4 text-sm font-extrabold text-[var(--accent-ink)] transition hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-50">
                          {busy ? 'Saving your order…' : `Pay ${money(total)} by card`}
                        </button>

                        <div className="my-7 flex items-center gap-4 text-xs font-extrabold uppercase tracking-[0.18em] text-[var(--muted)]"><span className="h-px flex-1 bg-[var(--line)]" />or pay with<span className="h-px flex-1 bg-[var(--line)]" /></div>

                        <div className="grid gap-3 sm:grid-cols-2">
                          <button onClick={() => showToast('Apple Pay selected. Complete payment on your device to finish this order.')} className="flex h-[52px] items-center justify-center rounded-full bg-black px-5 transition hover:-translate-y-0.5">
                            <img src={applePayLogo} alt="Apple Pay" className="h-7 object-contain invert" />
                          </button>
                          <button onClick={() => showToast('Google Pay selected. Complete payment in Google Pay to finish this order.')} className="flex h-[52px] items-center justify-center rounded-full border border-[var(--line)] bg-white px-5 transition hover:-translate-y-0.5">
                            <img src={googlePayLogo} alt="Google Pay" className="h-7 object-contain" />
                          </button>
                        </div>

                        <a href="https://www.paypal.com/checkout" target="_blank" rel="noopener" onClick={() => showToast('Redirecting to PayPal…')} className="mt-3 flex h-[58px] w-full items-center justify-center gap-3 rounded-full bg-[#FFC439] px-6 text-[#003087] shadow-[0_14px_30px_rgba(255,196,57,0.35)] transition hover:-translate-y-0.5">
                          <img src={paypalLogo} alt="PayPal" className="h-8 object-contain" />
                          <span className="text-sm font-extrabold">Pay with PayPal</span>
                        </a>
                        <p className="mt-3 text-center text-xs text-[var(--muted)]">PayPal is the final payment option at checkout, as requested.</p>
                      </section>
                    </div>

                    <aside className="h-fit rounded-[26px] bg-[var(--surface-soft)] p-6">
                      <h2 className="text-xl font-extrabold">Order summary</h2>
                      <div className="mt-5 space-y-4">
                        {cartEntries.map(({ id, qty, item }) => (
                          <div key={id} className="flex items-center gap-3">
                            <img src={item.image} alt={item.title} className="h-14 w-12 rounded-[14px] object-cover" />
                            <div className="min-w-0 flex-1"><p className="truncate text-sm font-extrabold">{item.title}</p><p className="text-xs text-[var(--muted)]">Qty {qty}</p></div>
                            <b className="text-sm">{money(item.price * qty)}</b>
                          </div>
                        ))}
                      </div>
                      <div className="mt-6 border-t border-[var(--line)] pt-5">
                        <label className="text-xs font-extrabold uppercase tracking-[0.16em] text-[var(--muted)]">Discount code</label>
                        {appliedDiscount ? (
                          <div className="mt-3 flex items-center justify-between rounded-full bg-[var(--surface)] px-4 py-3 text-sm font-extrabold">
                            <span className="flex items-center gap-2"><BadgePercent className="h-4 w-4" />{appliedDiscount.code} · -{appliedDiscount.pct}%</span>
                            <button onClick={() => { setAppliedDiscount(null); showToast('Discount removed.'); }} aria-label="Remove discount"><X className="h-4 w-4" /></button>
                          </div>
                        ) : (
                          <div className="mt-3 flex gap-2">
                            <input value={discountInput} onChange={(e) => setDiscountInput(e.target.value)} placeholder="VELLE20" className="min-w-0 flex-1 rounded-full border border-[var(--line)] bg-[var(--surface)] px-4 py-3 text-sm font-bold uppercase outline-none" />
                            <button onClick={applyDiscount} className="rounded-full bg-[var(--accent)] px-4 py-3 text-sm font-extrabold text-[var(--accent-ink)]">Apply</button>
                          </div>
                        )}
                        <p className="mt-2 text-xs text-[var(--muted)]">Try VELLE20, FIRST10, GLOW15 or PARIS25.</p>
                      </div>
                      <SummaryRows subtotal={subtotal} compareSubtotal={compareSubtotal} discountAmount={discountAmount} shipping={shipping} total={total} money={money} appliedDiscount={appliedDiscount} />
                    </aside>
                  </div>
                )}
              </section>
            )}

            {page === 'account' && currentUser && (
              <section className="rise-in py-8">
                <div className="flex flex-wrap items-center justify-between gap-4"><div><p className="text-xs font-extrabold uppercase tracking-[0.2em] text-[var(--muted)]">Dashboard</p><h1 className="mt-2 text-[36px] font-extrabold tracking-[-0.04em] sm:text-[48px]">Bonjour, {currentUser.email}</h1><p className="text-[var(--muted)]">{currentUser.name} · Track orders, receipts and your ritual shelf.</p></div><button onClick={() => { setCurrentUser(null); setAccountDone(false); showToast('Logged out.'); }} className="rounded-full border border-[var(--line)] px-5 py-3 text-sm font-extrabold">Logout</button></div>
                <div className="mt-6 grid gap-4 sm:grid-cols-3">
                  <div className="rounded-[22px] bg-[var(--surface-soft)] p-5"><p className="text-xs font-extrabold uppercase text-[var(--muted)]">Total orders</p><p className="mt-2 text-3xl font-extrabold">{userOrders.length}</p></div>
                  <div className="rounded-[22px] bg-[var(--surface-soft)] p-5"><p className="text-xs font-extrabold uppercase text-[var(--muted)]">Total spent</p><p className="mt-2 text-3xl font-extrabold">{money(userOrders.reduce((s,o)=>s+Number(o.total||0),0))}</p><p className="text-xs text-[var(--muted)]">Currency {currency}</p></div>
                  <div className="rounded-[22px] bg-[var(--surface-soft)] p-5"><p className="text-xs font-extrabold uppercase text-[var(--muted)]">Member since</p><p className="mt-2 text-lg font-extrabold">{currentUser.created_at ? new Date(currentUser.created_at).toLocaleDateString() : new Date().toLocaleDateString()}</p></div>
                </div>
                <div className="mt-6 flex flex-wrap gap-2">{(['orders','profile','addresses','wishlist'] as const).map(t => <button key={t} onClick={() => setDashTab(t)} className={`rounded-full px-5 py-2.5 text-sm font-extrabold capitalize ${dashTab===t?'bg-[var(--accent)] text-[var(--accent-ink)]':'border border-[var(--line)]'}`}>{t}</button>)}</div>
                {dashTab==='orders' && <div className="mt-6 space-y-4">{userOrders.length===0 ? <div className="rounded-[24px] bg-[var(--surface-soft)] p-8 text-center"><p className="text-xl font-extrabold">No orders yet</p><button onClick={()=>go('shop')} className="mt-4 rounded-full bg-[var(--accent)] px-6 py-3 text-sm font-extrabold text-[var(--accent-ink)]">Shop Maison Velle</button></div> : userOrders.map((ord:any) => { const steps=['Processing','Shipped','Delivered']; const stepIdx = ord.status==='Delivered'?2:ord.status==='Shipped'?1:0; const expanded = expandedOrder===(ord.orderNumber||ord.id); return <article key={ord.id} className="rounded-[24px] border border-[var(--line)] p-5"><div className="flex flex-wrap justify-between gap-3"><div><p className="font-extrabold">{ord.orderNumber||ord.id} · {ord.created_at?new Date(ord.created_at).toLocaleDateString():''}</p><p className="text-sm text-[var(--muted)]">Status: {ord.status||'Processing'} · Carrier {ord.carrier||'DHL Paris'} · ETA {ord.eta||'3-5 business days'}</p><p className="text-sm">Tracking: <button onClick={()=>showToast(`Tracking ${ord.trackingNumber||''} copied to order detail`)} className="font-extrabold underline">{ord.trackingNumber||'MV-TRK-000000'}</button></p></div><b>{money(Number(ord.total||0))}</b></div><div className="mt-4 flex items-center">{steps.map((s,i)=><div key={s} className="flex flex-1 items-center last:flex-none"><span className={`grid h-8 w-8 place-items-center rounded-full text-xs font-extrabold ${i<=stepIdx?'bg-[var(--accent)] text-[var(--accent-ink)]':'bg-[var(--surface-soft)] text-[var(--muted)]'}`}>{i+1}</span><span className="ml-2 text-xs font-bold">{s}</span>{i<2 && <span className={`mx-3 h-0.5 flex-1 ${i<stepIdx?'bg-[var(--accent)]':'bg-[var(--line)]'}`}/>}</div>)}</div><div className="mt-4 space-y-2">{(ord.items||[]).map((it:any,idx:number)=>{ const prod=PRODUCTS.find(p=>p.id===it.productId); return <div key={idx} className="flex items-center gap-3">{prod && <img src={prod.image} alt={it.title} className="h-12 w-10 rounded-lg object-cover"/>}<span className="flex-1 text-sm font-bold">{it.title} × {it.qty}</span><span className="text-sm">{money(it.unitPrice*it.qty)}</span></div>})}</div><div className="mt-4 flex flex-wrap gap-2"><button onClick={()=>setExpandedOrder(expanded?'':(ord.orderNumber||ord.id))} className="rounded-full border border-[var(--line)] px-4 py-2 text-xs font-extrabold">{expanded?'Hide tracking':'Track order'}</button><button onClick={()=>setReceiptOrder(ord)} className="rounded-full border border-[var(--line)] px-4 py-2 text-xs font-extrabold">Receipt</button><button onClick={()=>downloadReceipt(ord)} className="rounded-full border border-[var(--line)] px-4 py-2 text-xs font-extrabold">Download receipt (.txt)</button><button onClick={()=>{(ord.items||[]).forEach((it:any)=>addToCart(it.productId,it.qty,true)); showToast('Reordered items added to bag.'); go('cart');}} className="rounded-full bg-[var(--accent)] px-4 py-2 text-xs font-extrabold text-[var(--accent-ink)]">Reorder</button></div>{expanded && <div className="mt-4 rounded-[18px] bg-[var(--surface-soft)] p-4 text-sm leading-7"><p><b>Delivery updates:</b> Order confirmed in Paris → Packed at Le Marais atelier → {ord.status||'Processing'} with {ord.carrier||'DHL Paris'}.</p><div className="mt-3 grid h-28 place-items-center rounded-[14px] bg-[var(--beige)] text-[var(--muted)]">Map placeholder · {ord.trackingNumber} · ETA {ord.eta}</div><p className="mt-3">Support: <a className="font-bold underline" href="mailto:bonjour@maisonvelle.example">bonjour@maisonvelle.example</a> · <a className="font-bold underline" href="tel:+33100000000">+33 1 00 00 00 00</a></p></div>}</article>})}</div>}
                {dashTab==='profile' && <div className="mt-6 max-w-[560px] space-y-4 rounded-[24px] border border-[var(--line)] p-6"><Field label="Email"><input value={account.email||currentUser.email} onChange={e=>setAccount({...account,email:e.target.value})} className="checkout-input"/></Field><Field label="Phone"><input value={account.phone} onChange={e=>setAccount({...account,phone:e.target.value})} placeholder="+33 ..." className="checkout-input"/></Field><Field label="Password"><input type="password" value={account.password} onChange={e=>setAccount({...account,password:e.target.value})} placeholder="New password" className="checkout-input"/></Field><button onClick={()=>{setCurrentUser({...currentUser,email:account.email||currentUser.email}); showToast('Profile updated.');}} className="rounded-full bg-[var(--accent)] px-6 py-3 text-sm font-extrabold text-[var(--accent-ink)]">Save profile</button></div>}
                {dashTab==='addresses' && <div className="mt-6 grid gap-4 lg:grid-cols-2"><div className="space-y-3">{addresses.length===0 && <p className="rounded-[20px] bg-[var(--surface-soft)] p-5 text-[var(--muted)]">No saved addresses yet. Add one on the right.</p>}{addresses.map((a,i)=><div key={i} className="rounded-[20px] border border-[var(--line)] p-4"><b>{a.label}</b><p className="text-sm text-[var(--muted)]">{a.address}, {a.city} {a.postal}, {a.country}</p></div>)}</div><div className="space-y-3 rounded-[20px] bg-[var(--surface-soft)] p-5"><input value={newAddress.label} onChange={e=>setNewAddress({...newAddress,label:e.target.value})} placeholder="Label" className="checkout-input"/><input value={newAddress.address} onChange={e=>setNewAddress({...newAddress,address:e.target.value})} placeholder="Address" className="checkout-input"/><input value={newAddress.city} onChange={e=>setNewAddress({...newAddress,city:e.target.value})} placeholder="City" className="checkout-input"/><input value={newAddress.postal} onChange={e=>setNewAddress({...newAddress,postal:e.target.value})} placeholder="Postal" className="checkout-input"/><button onClick={()=>{if(newAddress.address.trim().length<5){showToast('Enter a valid address.');return;} setAddresses(p=>[...p,newAddress]); showToast('Address saved.');}} className="rounded-full bg-[var(--accent)] px-5 py-3 text-sm font-extrabold text-[var(--accent-ink)]">Save address</button></div></div>}
                {dashTab==='wishlist' && <div className="mt-6">{wishlist.length===0 ? <div className="rounded-[24px] bg-[var(--surface-soft)] p-6"><p className="font-extrabold">Wishlist is empty — tap a product to save it here.</p><div className="mt-4 flex flex-wrap gap-2">{PRODUCTS.slice(0,4).map(p=><button key={p.id} onClick={()=>setWishlist(w=>[...w,p.id])} className="rounded-full border border-[var(--line)] bg-[var(--surface)] px-4 py-2 text-xs font-extrabold">Save {p.title}</button>)}</div></div> : <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{PRODUCTS.filter(p=>wishlist.includes(p.id)).map(p=><ProductCard key={p.id} product={p} money={money} onOpen={()=>openProduct(p)} onBuy={()=>{addToCart(p.id); go('cart');}} buyLabel={copy.shopNow}/>)}</div>}</div>}
              </section>
            )}

            {page === 'account' && !currentUser && (
              <section className="rise-in mx-auto max-w-[680px] py-8 sm:py-12">
                <div className="rounded-[30px] border border-[var(--line)] bg-[var(--surface)] p-6 shadow-[var(--shadow)] sm:p-9">
                  <p className="text-xs font-extrabold uppercase tracking-[0.2em] text-[var(--muted)]">Maison Velle</p>
                  <h1 className="mt-3 text-[40px] font-extrabold tracking-[-0.05em]">{authMode==='signup'?'Create your account':'Welcome back'}</h1>
                  <p className="mt-3 leading-7 text-[var(--muted)]">Save your bag, orders and ritual preferences in Maison Velle records. Storage is shared across the app and capped at 1,000 records.</p>
                  <div className="mt-5 flex gap-2"><button onClick={()=>setAuthMode('signup')} className={`rounded-full px-4 py-2 text-xs font-extrabold ${authMode==='signup'?'bg-[var(--accent)] text-[var(--accent-ink)]':'border border-[var(--line)]'}`}>Sign Up</button><button onClick={()=>setAuthMode('signin')} className={`rounded-full px-4 py-2 text-xs font-extrabold ${authMode==='signin'?'bg-[var(--accent)] text-[var(--accent-ink)]':'border border-[var(--line)]'}`}>Sign In</button></div>
                  <div className="mt-7 space-y-3">
                    <button onClick={() => showToast('Redirecting to Google sign-in…')} className="flex h-12 w-full items-center justify-center gap-3 rounded-full border border-[var(--line)] bg-[var(--surface)] text-sm font-extrabold transition hover:-translate-y-0.5 hover:bg-[var(--surface-soft)]"><GoogleMark /> Continue with Google</button>
                    <button onClick={() => showToast('Redirecting to Apple sign-in…')} className="flex h-12 w-full items-center justify-center gap-3 rounded-full bg-black text-sm font-extrabold text-white transition hover:-translate-y-0.5"><AppleIcon className="h-5 w-5 fill-current" /> Continue with Apple</button>
                  </div>
                  <div className="my-6 flex items-center gap-4 text-xs font-extrabold uppercase tracking-[0.18em] text-[var(--muted)]"><span className="h-px flex-1 bg-[var(--line)]" />or<span className="h-px flex-1 bg-[var(--line)]" /></div>
                    <div className="space-y-4">
                      {authMode==='signup' && <Field label="Full name"><input value={account.name} onChange={(e) => setAccount({ ...account, name: e.target.value })} placeholder="Your name" className="checkout-input" /></Field>}
                      <Field label="Email"><input value={account.email} onChange={(e) => setAccount({ ...account, email: e.target.value })} placeholder="you@example.com" className="checkout-input" /></Field>
                      <Field label="Phone"><input value={account.phone} onChange={(e) => setAccount({ ...account, phone: e.target.value })} placeholder="+33 ..." className="checkout-input" /></Field>
                      <Field label="Password"><input type="password" value={account.password} onChange={(e) => setAccount({ ...account, password: e.target.value })} placeholder="Password" className="checkout-input" /></Field>
                      <button disabled={busy} onClick={submitAccount} className="w-full rounded-full bg-[var(--accent)] px-6 py-4 text-sm font-extrabold text-[var(--accent-ink)] transition hover:-translate-y-0.5 disabled:opacity-50">{busy ? 'Please wait…' : authMode==='signup'?'Create account':'Sign In'}</button>
                    </div>
                </div>
              </section>
            )}

            {page === 'confirmation' && (
              <section className="rise-in mx-auto max-w-[720px] py-10 text-center sm:py-16">
                <span className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-[var(--accent)] text-[var(--accent-ink)]"><Check className="h-8 w-8" /></span>
                <h1 className="mt-6 text-[44px] font-extrabold tracking-[-0.05em]">Merci. Order confirmed.</h1>
                <p className="mx-auto mt-4 max-w-[520px] leading-7 text-[var(--muted)]">Order <b className="text-[var(--ink)]">{order?.id}</b> was paid by {order?.method || 'card'} for <b className="text-[var(--ink)]">{money(order?.total || 0)}</b>. A receipt record has been saved in Maison Velle orders.</p>
                <div className="mt-8 flex flex-wrap justify-center gap-3">
                  <button onClick={() => go('shop')} className="rounded-full bg-[var(--accent)] px-6 py-3 text-sm font-extrabold text-[var(--accent-ink)]">Continue shopping</button>
                  <button onClick={() => go('home')} className="rounded-full border border-[var(--line)] px-6 py-3 text-sm font-extrabold">Back home</button>
                </div>
              </section>
            )}
          </main>

          <footer id="contact" className="border-t border-[var(--line)] px-5 py-9 sm:px-7">
            <div className="grid gap-8 md:grid-cols-[1.2fr_1fr_1fr]">
              <div>
                <p className="text-[30px] font-extrabold lowercase tracking-[-0.05em]">maison velle.</p>
                <p className="mt-3 max-w-[420px] leading-7 text-[var(--muted)]">Cosmetics for the whole body. For every body. Designed in Le Marais, made for daily rituals everywhere.</p>
              </div>
              <div>
                <p className="text-xs font-extrabold uppercase tracking-[0.18em] text-[var(--muted)]">Visit</p>
                <p className="mt-3 flex items-start gap-2 leading-7"><MapPin className="mt-1 h-4 w-4 shrink-0" /> Maison Velle Atelier<br />Le Marais, Paris</p>
              </div>
              <div>
                <p className="text-xs font-extrabold uppercase tracking-[0.18em] text-[var(--muted)]">Contact</p>
                <a href="mailto:bonjour@maisonvelle.example" className="mt-3 flex items-center gap-2 font-bold hover:underline"><Mail className="h-4 w-4" /> bonjour@maisonvelle.example</a>
                <a href="tel:+33100000000" className="mt-2 flex items-center gap-2 font-bold hover:underline"><Phone className="h-4 w-4" /> +33 1 00 00 00 00</a>
              </div>
            </div>
            <div className="mt-8 flex flex-wrap items-center gap-3 border-t border-[var(--line)] pt-5">
              <span className="font-mono text-[11px] font-bold uppercase tracking-[0.14em] text-[var(--muted)]">Accepted payments:</span>
              <div className="flex flex-wrap gap-2">
                {[['Visa', visaLogo], ['Mastercard', mastercardLogo], ['Amex', amexLogo], ['Maestro', maestroLogo], ['Verve', verveLogo], ['Discover', discoverLogo], ['PayPal', paypalLogo], ['Apple Pay', applePayLogo], ['Google Pay', googlePayLogo]].map(([label, logo]) => (
                  <span key={label} className="grid h-9 w-14 place-items-center overflow-hidden rounded-[10px] border border-black/10 bg-white shadow-sm dark:bg-neutral-800" title={label}><img src={logo as string} alt={label} className="max-h-6 max-w-11 object-contain" /></span>
                ))}
              </div>
            </div>
            <div className="mt-5 flex flex-wrap items-center justify-between gap-3 border-t border-[var(--line)] pt-5 text-xs text-[var(--muted)]">
              <span>© Maison Velle. Vegan · cruelty-free · paraben-free · fragrance-free · pH 5.5.</span>
              <span>{backendNote}</span>
            </div>
          </footer>
        </div>
      </div>

      <button onClick={() => setAssistantOpen(!assistantOpen)} className="fixed bottom-5 right-5 z-50 flex items-center gap-2 rounded-full bg-[var(--accent)] px-5 py-3.5 text-sm font-extrabold text-[var(--accent-ink)] shadow-2xl transition hover:-translate-y-0.5">
        <Brain className="h-5 w-5" /> Velle AI
      </button>

      {assistantOpen && (
        <section className="fixed bottom-24 right-3 z-50 flex max-h-[560px] w-[calc(100vw-24px)] max-w-[390px] flex-col overflow-hidden rounded-[26px] border border-[var(--line)] bg-[var(--surface)] shadow-2xl sm:right-5">
          <div className="flex items-center justify-between border-b border-[var(--line)] p-4">
            <div><p className="font-extrabold">Velle ritual assistant</p><p className="text-xs text-[var(--muted)]">Private, in-page guidance. No external chat is contacted.</p></div>
            <button onClick={() => setAssistantOpen(false)} className="grid h-9 w-9 place-items-center rounded-full bg-[var(--surface-soft)]" aria-label="Close assistant"><X className="h-4 w-4" /></button>
          </div>
          <div className="flex-1 space-y-3 overflow-y-auto p-4">
            {messages.map((message, i) => (
              <div key={i} className={`max-w-[86%] rounded-[18px] px-4 py-3 text-sm leading-6 ${message.role === 'user' ? 'ml-auto bg-[var(--accent)] text-[var(--accent-ink)]' : 'bg-[var(--surface-soft)] text-[var(--ink)]'}`}>{message.text}</div>
            ))}
            {assistantPhase !== 'idle' && (
              <div className="flex items-center gap-2 rounded-[18px] bg-[var(--surface-soft)] px-4 py-3 text-sm font-bold text-[var(--muted)]"><Sparkles className="h-4 w-4 animate-pulse" />{assistantPhase === 'thinking' ? 'Thinking…' : 'Analyzing your ritual…'}</div>
            )}
          </div>
          <div className="border-t border-[var(--line)] p-3">
            <div className="mb-3 flex flex-wrap gap-2">
              {['Sensitive skin', 'Best bundle', 'What is inside?'].map((chip) => <button key={chip} onClick={() => askAssistant(chip)} className="rounded-full border border-[var(--line)] px-3 py-1.5 text-xs font-extrabold transition hover:-translate-y-0.5">{chip}</button>)}
            </div>
            <div className="flex gap-2">
              <input value={assistantInput} onChange={(e) => setAssistantInput(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') askAssistant(); }} placeholder="Ask about a ritual…" className="min-w-0 flex-1 rounded-full border border-[var(--line)] bg-[var(--surface-soft)] px-4 py-3 text-sm outline-none" />
              <button onClick={() => askAssistant()} className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-[var(--accent)] text-[var(--accent-ink)]" aria-label="Send message"><Send className="h-4 w-4" /></button>
            </div>
          </div>
        </section>
      )}

      {verifyModal && <div className="fixed inset-0 z-[70] grid place-items-center bg-black/50 p-4"><div className="w-full max-w-[440px] rounded-[26px] bg-[var(--surface)] p-7 text-center shadow-2xl"><Mail className="mx-auto h-10 w-10" /><h2 className="mt-4 text-2xl font-extrabold">Verification email sent to {verifyModal}</h2><p className="mt-3 leading-7 text-[var(--muted)]">Please check your inbox to verify your account. We've sent authentication link to {verifyModal}</p><p className="mt-4 text-sm font-bold">Verifying…</p></div></div>}
      {receiptOrder && <div className="fixed inset-0 z-[70] grid place-items-center bg-black/50 p-4"><div className="max-h-[90vh] w-full max-w-[520px] overflow-y-auto rounded-[26px] bg-[var(--surface)] p-7 shadow-2xl"><div className="flex justify-between"><h2 className="text-2xl font-extrabold">Receipt</h2><button onClick={()=>setReceiptOrder(null)} className="grid h-9 w-9 place-items-center rounded-full bg-[var(--surface-soft)]"><X className="h-4 w-4"/></button></div><p className="mt-2 text-sm text-[var(--muted)]">Order {receiptOrder.orderNumber||receiptOrder.id} · {receiptOrder.created_at?new Date(receiptOrder.created_at).toLocaleString():''}<br/>Tracking {receiptOrder.trackingNumber} · {receiptOrder.carrier||'DHL Paris'} · ETA {receiptOrder.eta||'3-5 business days'}<br/>Payment {receiptOrder.paymentMethod} ****{receiptOrder.cardLast4} · Billing {receiptOrder.billingAddress}, {receiptOrder.city} {receiptOrder.postal}</p><div className="mt-4 space-y-2">{(receiptOrder.items||[]).map((it:any,i:number)=><div key={i} className="flex justify-between text-sm"><span>{it.title} × {it.qty}</span><b>{money(it.unitPrice*it.qty)}</b></div>)}</div><dl className="mt-4 space-y-2 border-t border-[var(--line)] pt-4 text-sm"><div className="flex justify-between"><dt>Subtotal</dt><dd>{money(Number(receiptOrder.subtotal||0))}</dd></div><div className="flex justify-between"><dt>Discount {receiptOrder.discount?.code||''}</dt><dd>-{money(Number(receiptOrder.discountAmount||0))}</dd></div><div className="flex justify-between"><dt>Shipping</dt><dd>{money(Number(receiptOrder.shipping||0))}</dd></div><div className="flex justify-between text-base font-extrabold"><dt>Total</dt><dd>{money(Number(receiptOrder.total||0))}</dd></div></dl><p className="mt-3 text-xs text-[var(--muted)]">Receipt sent to {receiptOrder.email} · Order confirmation email sent</p><div className="mt-5 flex gap-2"><button onClick={()=>downloadReceipt(receiptOrder)} className="flex-1 rounded-full bg-[var(--accent)] px-4 py-3 text-sm font-extrabold text-[var(--accent-ink)]">Download receipt (.txt)</button><button onClick={()=>{setReceiptOrder(null); if(page==='checkout') go('confirmation');}} className="rounded-full border border-[var(--line)] px-4 py-3 text-sm font-extrabold">Close</button></div></div></div>}
      {toast && <div className="toast-in fixed bottom-5 left-1/2 z-[60] w-[calc(100vw-32px)] max-w-[440px] -translate-x-1/2 rounded-full bg-neutral-950 px-5 py-3.5 text-center text-sm font-bold text-white shadow-2xl">{toast}</div>}

      <style>{`.checkout-input{width:100%;border:1px solid var(--line);background:var(--surface);color:var(--ink);border-radius:999px;padding:0.85rem 1rem;font-size:0.9rem;outline:none}.checkout-input:focus{border-color:var(--ink);box-shadow:0 0 0 3px color-mix(in srgb,var(--ink) 12%,transparent)}.checkout-input::placeholder{color:var(--muted)}`}</style>
    </div>
  );
}

function MagneticButton({ children, onClick, className = '' }: { children: React.ReactNode; onClick?: () => void; className?: string }) {
  const [transform, setTransform] = useState('translate(0px, 0px)');
  return (
    <button
      onClick={onClick}
      onMouseMove={(e) => {
        const rect = e.currentTarget.getBoundingClientRect();
        const x = (e.clientX - rect.left - rect.width / 2) * 0.16;
        const y = (e.clientY - rect.top - rect.height / 2) * 0.22;
        setTransform(`translate(${x}px, ${y}px)`);
      }}
      onMouseLeave={() => setTransform('translate(0px, 0px)')}
      style={{ transform }}
      className={`inline-flex items-center justify-center gap-2 rounded-full px-6 py-3.5 text-sm font-extrabold transition-transform duration-200 ${className}`}
    >
      {children}
    </button>
  );
}

function CategoryTile({ label, title, color, image, onClick }: { label: string; title: string; color: string; image: string; onClick: () => void }) {
  return (
    <button onClick={onClick} className="group relative min-h-[230px] overflow-hidden rounded-[20px] p-5 text-left transition duration-300 hover:-translate-y-1" style={{ background: color }}>
      <span className="absolute right-4 top-4 z-10 grid h-9 w-9 place-items-center rounded-full bg-white text-neutral-950 shadow transition group-hover:rotate-45"><ArrowUpRight className="h-4 w-4" /></span>
      <span className="relative z-10 text-xs font-extrabold lowercase tracking-[0.08em] text-neutral-700">{label}</span>
      <img src={image} alt={title} className="absolute bottom-0 right-0 h-[78%] w-[72%] object-cover object-center [mask-image:linear-gradient(to_left,black_78%,transparent)]" />
      <span className="absolute bottom-5 left-5 z-10 text-[24px] font-extrabold tracking-[-0.03em] text-neutral-950">{title}</span>
    </button>
  );
}

function ProductCard({ product, money, onOpen, onBuy, buyLabel }: { product: Product; money: (n: number) => string; onOpen: () => void; onBuy: () => void; buyLabel: string }) {
  const [tilt, setTilt] = useState<React.CSSProperties>({});
  const sale = Math.round((1 - product.price / product.compareAt) * 100);
  return (
    <article
      onMouseMove={(e) => {
        const rect = e.currentTarget.getBoundingClientRect();
        const px = (e.clientX - rect.left) / rect.width;
        const py = (e.clientY - rect.top) / rect.height;
        setTilt({ '--rx': `${(0.5 - py) * 7}deg`, '--ry': `${(px - 0.5) * 7}deg`, '--mx': `${px * 100}%`, '--my': `${py * 100}%` } as React.CSSProperties);
      }}
      onMouseLeave={() => setTilt({})}
      style={tilt}
      className="tilt-card group relative overflow-hidden rounded-[20px] border border-[var(--line)] bg-[var(--surface)] shadow-sm hover:shadow-[var(--shadow)]"
    >
      <button onClick={onOpen} className="block w-full text-left" aria-label={`Open ${product.title}`}>
        <span className="relative block aspect-[4/5] overflow-hidden bg-[var(--surface-soft)]">
          <img src={product.image} alt={product.title} className="absolute inset-0 h-full w-full object-cover transition duration-700 group-hover:scale-[1.03]" />
          <img src={product.hover} alt={product.title} className="absolute inset-0 h-full w-full object-cover opacity-0 transition duration-700 group-hover:scale-[1.03] group-hover:opacity-100" />
          <span className="absolute left-3 top-3 rounded-full bg-white/90 px-2.5 py-1 text-[11px] font-extrabold text-neutral-950">{product.no}</span>
          <span className="absolute right-3 top-3 rounded-full bg-neutral-950 px-2.5 py-1 text-[11px] font-extrabold text-white">-{sale}%</span>
        </span>
        <span className="block p-4">
          <span className="text-[11px] font-extrabold uppercase tracking-[0.14em] text-[var(--muted)]">( {product.audience} )</span>
          <span className="mt-1 block text-[17px] font-extrabold leading-tight">{product.title}</span>
          <span className="mt-1 line-clamp-2 block text-sm leading-5 text-[var(--muted)]">{product.subtitle}</span>
          <span className="mt-3 flex items-baseline gap-2"><b>{money(product.price)}</b><s className="text-sm text-[var(--muted)]">{money(product.compareAt)}</s></span>
        </span>
      </button>
      <div className="px-4 pb-4">
        <button onClick={onBuy} className="flex w-full items-center justify-center gap-2 rounded-full bg-[var(--accent)] px-5 py-3 text-sm font-extrabold text-[var(--accent-ink)] transition hover:-translate-y-0.5">
          {buyLabel} <ArrowRight className="h-4 w-4" />
        </button>
      </div>
    </article>
  );
}

function BundleSection({ selectedBundles, setSelectedBundles, offers, setOffers, money, onAdd, showToast }: {
  selectedBundles: string[];
  setSelectedBundles: React.Dispatch<React.SetStateAction<string[]>>;
  offers: string[];
  setOffers: React.Dispatch<React.SetStateAction<string[]>>;
  money: (n: number) => string;
  onAdd: () => void;
  showToast: (text: string) => void;
}) {
  const toggleBundle = (id: string) => setSelectedBundles((prev) => prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]);
  const toggleOffer = (id: string) => {
    setOffers((prev) => prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]);
    showToast('Offer preference updated.');
  };
  return (
    <section className="rounded-[28px] bg-[var(--surface-soft)] p-6 sm:p-8">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-xs font-extrabold uppercase tracking-[0.2em] text-[var(--muted)]">Bundles · Pricing</p>
          <h2 className="mt-2 text-[32px] font-extrabold tracking-[-0.04em] sm:text-[42px]">Choose your ritual</h2>
        </div>
        <button onClick={onAdd} className="rounded-full bg-[var(--accent)] px-5 py-3 text-sm font-extrabold text-[var(--accent-ink)] transition hover:-translate-y-0.5">Add selected bundles</button>
      </div>
      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        {BUNDLES.map((bundle) => {
          const selected = selectedBundles.includes(bundle.id);
          return (
            <article key={bundle.id} className={`overflow-hidden rounded-[22px] bg-[var(--surface)] ring-offset-2 transition ${selected ? 'ring-2 ring-[var(--ink)]' : 'ring-1 ring-[var(--line)]'}`}>
              <img src={bundle.image} alt={bundle.title} className="h-44 w-full object-cover" />
              <div className="p-5">
                <label className="flex cursor-pointer items-start gap-3">
                  <input type="checkbox" checked={selected} onChange={() => toggleBundle(bundle.id)} className="mt-1 h-5 w-5 accent-neutral-950" />
                  <span><span className="block text-xl font-extrabold">{bundle.title}</span><span className="mt-1 block text-sm leading-6 text-[var(--muted)]">{bundle.subtitle}</span></span>
                </label>
                <ul className="mt-4 space-y-2 text-sm text-[var(--muted)]">{bundle.items.map((item) => <li key={item} className="flex gap-2"><Check className="mt-0.5 h-4 w-4 shrink-0 text-[var(--ink)]" />{item}</li>)}</ul>
                <div className="mt-5 flex items-baseline gap-2"><span className="text-2xl font-extrabold">{money(bundle.price)}</span><s className="text-[var(--muted)]">{money(bundle.compareAt)}</s><span className="rounded-full bg-[var(--beige)] px-2.5 py-1 text-xs font-extrabold">Save {money(bundle.save)}</span></div>
              </div>
            </article>
          );
        })}
      </div>
      <div className="mt-6 flex flex-wrap gap-3">
        {[['samples', 'Two discovery samples'], ['gift', 'Le Marais gift wrap'], ['concierge', 'Ritual concierge note']].map(([id, label]) => (
          <label key={id} className={`flex cursor-pointer items-center gap-2 rounded-full border px-4 py-2.5 text-sm font-extrabold transition ${offers.includes(id) ? 'border-[var(--ink)] bg-[var(--surface)]' : 'border-[var(--line)] bg-transparent text-[var(--muted)]'}`}>
            <input type="checkbox" checked={offers.includes(id)} onChange={() => toggleOffer(id)} className="h-4 w-4 accent-neutral-950" />{label}
          </label>
        ))}
      </div>
    </section>
  );
}

function DetailBlock({ title, items }: { title: string; items: string[] }) {
  return (
    <div className="mt-6 rounded-[22px] border border-[var(--line)] p-5">
      <h3 className="font-extrabold">{title}</h3>
      <div className="mt-3 flex flex-wrap gap-2">{items.map((item) => <span key={item} className="rounded-full bg-[var(--surface-soft)] px-3.5 py-2 text-sm font-bold">{item}</span>)}</div>
    </div>
  );
}

function SummaryRows({ subtotal, compareSubtotal, discountAmount, shipping, total, money, appliedDiscount }: {
  subtotal: number; compareSubtotal: number; discountAmount: number; shipping: number; total: number; money: (n: number) => string; appliedDiscount: { code: string; pct: number } | null;
}) {
  return (
    <dl className="mt-6 space-y-3 text-sm">
      <div className="flex justify-between"><dt className="text-[var(--muted)]">Sale subtotal</dt><dd className="font-extrabold">{money(subtotal)}</dd></div>
      <div className="flex justify-between"><dt className="text-[var(--muted)]">Product savings</dt><dd className="font-extrabold">-{money(Math.max(0, compareSubtotal - subtotal))}</dd></div>
      {appliedDiscount && <div className="flex justify-between"><dt className="text-[var(--muted)]">Code {appliedDiscount.code}</dt><dd className="font-extrabold">-{money(discountAmount)}</dd></div>}
      <div className="flex justify-between"><dt className="text-[var(--muted)]">Shipping</dt><dd className="font-extrabold">{shipping === 0 ? 'Free' : money(shipping)}</dd></div>
      <div className="flex justify-between border-t border-[var(--line)] pt-3 text-base"><dt className="font-extrabold">Total</dt><dd className="font-extrabold">{money(total)}</dd></div>
    </dl>
  );
}

function Field({ label, error, className = '', children }: { label: string; error?: string; className?: string; children: React.ReactNode }) {
  return (
    <label className={`block ${className}`}>
      <span className="mb-2 block text-xs font-extrabold uppercase tracking-[0.14em] text-[var(--muted)]">{label}</span>
      {children}
      {error && <span className="mt-1.5 block text-xs font-bold text-red-600">{error}</span>}
    </label>
  );
}
